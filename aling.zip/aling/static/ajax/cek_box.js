  ///Menandai checkbox
  $(function() {
    var typingTimer;
    var doneTypingInterval = 500;
    var searchInput = $('#cari-input');
    var url = $('#cari-form').attr('data-url');
    var entriesSelect = $('#tampil-page');
    var selectedData = []; // Menyimpan status ceklis

    function search() {
        var query = searchInput.val();
        var entries = entriesSelect.val();
        $.ajax({
            url: url,
            data: { search: query, entries: entries, selected_data: selectedData },
            success: function(data) {
                $('#cari-ajax').html(data);
                updateCheckboxStatus(); // Memperbarui status ceklis setelah memuat data baru
            }
        });
    }

    function updateCheckboxStatus() {
        $('.data-checkbox').each(function() {
            var id = $(this).val();
            if (selectedData.includes(id)) {
                $(this).prop('checked', true);
            } else {
                $(this).prop('checked', false);
            }
        });
    }

    searchInput.on('keyup', function() {
        clearTimeout(typingTimer);
        typingTimer = setTimeout(search, doneTypingInterval);
    });

    entriesSelect.on('change', function() {
        search();
    });

    // Mendengarkan perubahan pada ceklis
    $(document).on('change', '.data-checkbox', function() {
        var id = $(this).val();
        toggleCheckbox(id);
    });

    function toggleCheckbox(id) {
        var index = selectedData.indexOf(id);
        if (index !== -1) {
            selectedData.splice(index, 1); // Hapus dari daftar yang dipilih
        } else {
            selectedData.push(id); // Tambahkan ke daftar yang dipilih
        }
    }
    ///Menginput daftar barang yg dijual
    $('#btn-tampilkan-modal').click(function() {
        var kodeBarang = $('#kode-barang-input').val(); // Ambil kode barang dari input
        if (kodeBarang) {
            selectedData.push(kodeBarang); // Tambahkan kode barang ke daftar yang dipilih
        }

        if (selectedData.length > 0) {
            $.ajax({
                url: '{% url "j-ajaxmodal" %}',
                type: 'GET',
                data: { 'selected_data': selectedData },
                success: function(data) {
                    $('#modal-content').html(data);
                    $('#modal-data').modal('show');
                },
                error: function() {
                    Swal.fire('Terjadi kesalahan saat memuat data.');
                    return false;
                }
            });
        } else {
            Swal.fire('Pilih Setidaknya Satu Data !');
            return false;
        }
    });
});