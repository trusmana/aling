function Formset(element,$) {
  var addButton = element.querySelector('#addFormButton');
  var formsContainer = element.querySelector('.forms');
  var emptyForm = element.querySelector('.empty-form');
  // var totalDebet = element.querySelector('#total_debet');
  // var totalKredit = element.querySelector('#total_kredit');
  // var selisihJurnal = element.querySelector('#selisih_jurnal');

  var formCount = 0;

  function updateFormPrefixes() {
    var forms = element.querySelectorAll('.dynamic-form');
    for (var i = 0; i < forms.length; i++) {
      var form = forms[i];
      var prefix = 'ordered_items-' + i + '-';
      var inputs = form.querySelectorAll('input, select, textarea');

      for (var j = 0; j < inputs.length; j++) {
        var input = inputs[j];
        var name = input.getAttribute('name');
        if (name) {
          input.setAttribute('name', name.replace(/ordered_items-\d+-/g, prefix));
          input.setAttribute('id', input.getAttribute('id').replace(/ordered_items-\d+-/g, prefix));
        }
      }
    }
    element.querySelector('input[name=ordered_items-TOTAL_FORMS]').value = formCount;
  }

  // function updateTotals() {
  //   var debetInputs = element.querySelectorAll('.rp_debet');
  //   var kreditInputs = element.querySelectorAll('.rp_kredit');
  //   var totalDebetValue = 0;
  //   var totalKreditValue = 0;

  //   for (var i = 0; i < debetInputs.length; i++) {
  //     totalDebetValue += parseFloat(debetInputs[i].value || 0);
  //   }

  //   for (var i = 0; i < kreditInputs.length; i++) {
  //     totalKreditValue += parseFloat(kreditInputs[i].value || 0);
  //   }

  //   totalDebet.textContent = totalDebetValue.toFixed(2);
  //   totalKredit.textContent = totalKreditValue.toFixed(2);
  //   selisihJurnal.textContent = (totalDebetValue - totalKreditValue).toFixed(2);
  // }

  function addForm() {
    formCount++;
    var formPrefix = 'ordered_items-' + formCount + '-';
    var newForm = emptyForm.cloneNode(true);
    newForm.classList.remove('empty-form');
    newForm.classList.add('dynamic-form');
    newForm.setAttribute('id', 'ordered_items-' + formCount + '-row');

    var inputs = newForm.querySelectorAll('input, select, textarea');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      var name = input.getAttribute('name');
      if (name) {
        input.setAttribute('name', name.replace(/ordered_items-__prefix__-/g, formPrefix));
        input.setAttribute('id', input.getAttribute('id').replace(/ordered_items-__prefix__-/g, formPrefix));
        input.value = '';
        
      }
    }
    
    
    formsContainer.appendChild(newForm);
    updateFormPrefixes();
    //updateTotals();
    $('input:text').setMask();
    console.log(setMask,'lllllllllllll')
    
  }

  function removeForm(form) {
    formCount--;
    formsContainer.removeChild(form);
    updateFormPrefixes();
    //updateTotals();
  }


  formsContainer.addEventListener('click', function (event) {
    if (event.target.getAttribute('data-formset-remove-form') === 'true') {
      event.preventDefault();
      var form = event.target.closest('.dynamic-form');
      removeForm(form);
    }
  });

  addButton.addEventListener('click', function (event) {
    event.preventDefault();
    addForm();
  });
  

  //updateTotals();
}

var formsetElement = document.querySelector('#myFormset');
new Formset(formsetElement);

