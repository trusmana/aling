// Tampilkan modal ketika tombol "+" diklik
jQuery('#btn_add_customer').on('click', function() {
    jQuery('.form-customer input').val(''); // Kosongkan input form
    jQuery('.form-customer textarea').val('');
    jQuery('.form-customer select').val('');
    jQuery('#customerModal').modal('show'); // Tampilkan modal
});

// Saat tombol "Simpan Pelanggan" di modal diklik
jQuery('#modal_submit_button').on('click', function() {
    var customerData = jQuery('.form-customer').serialize(); // Ambil data form modal

    // Kirim data ke server menggunakan AJAX
    jQuery.ajax({
        url: "{% url 'add_customer' %}",  // URL untuk menyimpan data customer
        method: "POST",
        data: customerData,
        success: function(response) {
            // Tambahkan customer baru ke dropdown pelanggan
            var newCustomer = new Option(response.nama_customer, response.id, false, true);
            jQuery('#idcustomer').append(newCustomer).trigger('change');

            // Tutup modal setelah customer berhasil disimpan
            jQuery('#customerModal').modal('hide');
        },
        error: function(xhr) {
            // Tangani error
            alert("Error: " + xhr.responseText);
        }
    });
});
