var loadEditForm = function(url) {
  $.ajax({
    url: url,
    type: 'get',
    dataType: 'json',
    beforeSend: function() {
      $("#modal-data").modal("show");
    },
    success: function(data) {
      $("#modal-data .modal-content").html(data.html_form);
    }
  });
};
$("#ajax-table").on("click", ".js-edit-data", function() {
  var editUrl = $(this).data("url"); // Mendapatkan URL edit dari atribut data-url tombol edit
  loadEditForm(editUrl); // Memuat form edit menggunakan AJAX
});

// Fungsi untuk menyimpan form edit menggunakan AJAX
var saveEditForm = function() {
  var form = $("#js-edit-form");
  $.ajax({
    url: form.attr("action"),
    data: form.serialize(),
    type: form.attr("method"),
    dataType: 'json',
    success: function(data) {
      if (data.form_is_valid) {
        $("#ajax-table tbody").html(data.html_data_list);
        var Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          icon: 'warning',
          title: 'Data Berhasil Di Simpan '
        });
        $("#modal-data").modal("hide");
      } else {
        $("#modal-data .modal-content").html(data.html_form);
      }
    }
  });
};

// Mengikat event submit pada form edit dengan menggunakan ID js-edit-form
$("#modal-data").on("submit", "#js-edit-form", function() {
  saveEditForm(); // Menyimpan form edit menggunakan AJAX
  return false; // Mencegah form melakukan submit biasa
});