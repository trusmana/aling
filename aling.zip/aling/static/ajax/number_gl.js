$(function($) {
    $("input.uang").setMask();
    $("input.rp_kredit").keypress(function(event){
        if (event.charCode && (event.charCode < 46 || event.charCode > 57 || event.charCode == 47))
        { event.preventDefault(); }
    });
    $("input.rp_debet").keypress(function(event){
        if (event.charCode && (event.charCode < 46 || event.charCode > 57 || event.charCode == 47))
        { event.preventDefault(); }
    });
    $("input.rp_kredit").change(function() {
        updateJumlahDebet();
        updateJumlahKredit();
        if ($("#selisih_jurnal").html() != '0') { 
            setSubmitEnabled(false);
        } else { setSubmitEnabled(); }
    });
    $("input.rp_debet").change(function() {
        updateJumlahDebet();
        updateJumlahKredit();
        if ($("#selisih_jurnal").html() != '0') { 
            setSubmitEnabled(false);
        } else { setSubmitEnabled(); }
    });

    $("#myFormset").submit(function () {
        $("input.uang").each(function () {
            $(this).val(to_number($(this).val()));
        });
        return true;
    });
});    
function updateJumlahKredit() {
    var tot_kredit = 0;
    $("input.rp_kredit").each(function() {
        tot_kredit += parseFloat(to_number(this.value));
    });
    $("#total_kredit").text(format_number(String(tot_kredit)));
    $("#selisih_jurnal").text(format_number(String(to_number($("#total_debet").text()) - to_number($("#total_kredit").text()))));
}
function updateJumlahDebet() {
    var tot_debet = 0;
    $("input.rp_debet").each(function() {
        tot_debet += parseFloat(to_number(this.value));
    });
    $("#total_debet").text(format_number(String(tot_debet)));
    $("#selisih_jurnal").text(format_number(String(to_number($("#total_debet").text()) - to_number($("#total_kredit").text()))));
}
function setSubmitEnabled (state) {
    if (state==null & 
        ($("#total_kredit").html() != '0')) stat = '';
    else stat = 'disabled';
    $("input#id_simpan").attr("disabled",stat);
}


// Fungsi untuk mengubah format angka menjadi number
function format_number(num) {
    num = parseFloat(num).toFixed(2)
    var sre = new RegExp('([0-9]+)([0-9]{3})');
    var frac = String(num).split('.')[1];
    var decimal = String(num).split('.')[0];
    var ret_num = decimal + '';
    while (sre.test(ret_num)) { ret_num = ret_num.replace(sre, '$1' + '.' + '$2')}
    if ((frac == undefined) || (frac == '00')) { return ret_num; }
    else { return ret_num + ',' + frac; }
}
// Fungsi untuk mengubah format angka menjadi number
function to_number(str) {
    return parseFloat(str.replace(/\./g, '').replace(/,/g, '.'));
}


