$(function() {
  $(".uang").mask("000.000.000.000.000", {reverse: true});
  $('.tabular').submit(function(){
    $('input.uang').each(function () {
      $(this).val(to_number($(this).val()));
    });
    return true;
  });
  $("#tgllahir").datepicker({dateFormat: "dd-mm-yy",changeMonth: true,changeYear: true,});
  $('#id_nama,#id_tempat,#id_alamat_ktp,#id_kelurahan_ktp,#id_kecamatan_ktp,\
    #id_kota_kabupaten').keyup(function()
    {$(this).val($(this).val().toUpperCase());
  });
});
// Fungsi untuk memformat angka dengan tanda pemisah ribuan
function format_number(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}  
// Fungsi untuk mengubah format angka menjadi number
function to_number(str) {
  return parseFloat(str.replace(/\./g, '').replace(/,/g, '').replace(/[^\d.-]/g, ''));
}

