$(function () {
    var loadForm = function () {
        var btn = $(this);
        $.ajax({
            url: btn.attr("data-url"),
            type: 'get',
            dataType: 'json',
            beforeSend: function () {
              $("#modal-perusahaan").modal("show");
            },
            success: function (data) {
                $("#modal-perusahaan #id-content").html(data.html_form);
            },
          });
    };
    var saveForm = function () {
        var form = $(this);
        $.ajax({
          url: form.attr("action"),
          data: form.serialize(),
          type: form.attr("method"),
          dataType: 'json',
          success: function (data) {
            if (data.form_is_valid) {
              $("#ajax-table tbody").html(data.html_pers_list);
              $("#modal-perusahaan").modal("hide");
            }
            else {
              $("#modal-perusahaan #id-content").html(data.html_form);
            }
          }
        });
        return false;
      };
    
    ////Menu Untuk Meng  
    $(".js-create-data").click(loadForm);
    $("#modal-perusahaan").on("submit", ".js-prs-create-form", saveForm);

    // Delete Ajax
    $("#ajax-table").on("click", ".js-delete-data", loadForm);
    $("#modal-perusahaan").on("submit", ".js-delete-form", saveForm);


});

    