$(function() {
    var typingTimer;
    var doneTypingInterval = 500; // Waktu penundaan setelah pengguna selesai mengetik
    var searchInput = $('#cari-input');
    var url = $('#cari-form').attr('data-url');
    var entriesSelect = $('#tampil-page');
  
    // Fungsi untuk mengirim permintaan pencarian saat pengguna selesai mengetik
    function search() {
        var query = searchInput.val();
        var entries = entriesSelect.val(); // Mengambil nilai entri yang dipilih
        $.ajax({
            url: url,
            data: { search: query, entries: entries }, // Mengirim nilai entri ke view
            success: function(data) {
                $('#cari-ajax').html(data);
            }
        });
    }
  
    // Mendengarkan perubahan pada input pencarian
    searchInput.on('keyup', function() {
        clearTimeout(typingTimer);
        typingTimer = setTimeout(search, doneTypingInterval);
    });
  
    // Mendengarkan perubahan pada pilihan entri
    entriesSelect.on('change', function() {
        search(); // Memanggil fungsi pencarian saat pilihan entri berubah
    });
  });