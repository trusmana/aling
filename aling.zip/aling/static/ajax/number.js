$(document).ready(function($) {
  // Tambahkan mask ke semua input yang memiliki class .uang
  $('input.uang').on('input', function() {
      var value = $(this).val();
      // Format angka saat user mengetik
      $(this).val(format_number(value.replace(/\./g, '')));
  });

  // Saat form disubmit, ubah kembali angka ke format tanpa titik
  $('.tabular').submit(function(){
      $('input.uang').each(function () { 
          $(this).val(to_number($(this).val())); 
      });
      return true;
  });
});

// Fungsi untuk mengubah format angka menjadi string dengan titik sebagai pemisah ribuan
function format_number(num) {
  num = parseFloat(num).toFixed(2); // Mengatur desimal menjadi 2 digit
  var sre = new RegExp('([0-9]+)([0-9]{3})');
  var frac = String(num).split('.')[1]; // Mendapatkan bagian desimal
  var decimal = String(num).split('.')[0]; // Mendapatkan bagian bulat
  var ret_num = decimal + '';
  
  // Tambahkan titik sebagai pemisah ribuan
  while (sre.test(ret_num)) { 
      ret_num = ret_num.replace(sre, '$1' + '.' + '$2');
  }
  
  // Jika tidak ada angka desimal yang berarti, kembalikan angka bulat saja
  if ((frac == undefined) || (frac == '00')) { 
      return ret_num; 
  } else { 
      return ret_num + ',' + frac; // Kembalikan angka dengan desimal
  }
}

// Fungsi untuk mengubah string yang sudah diformat menjadi angka (menghapus titik dan mengganti koma dengan titik)
function to_number(str) {
  // Ganti semua titik dengan kosong, lalu ubah koma menjadi titik untuk format desimal
  return parseFloat(str.replace(/\./g, '').replace(/,/g, '.'));
}