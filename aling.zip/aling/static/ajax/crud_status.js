$(function () {
  // Fungsi untuk menampilkan modal atau alert saat melakukan perubahan status
  var changeStatus = function () {
    var btn = $(this);
    Swal.fire({
      title: "Apakah Anda yakin?",
      text: "Status data akan diubah!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Ya, ubah status!",
      cancelButtonText: "Batal",
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          url: btn.attr("data-url"),
          type: "post",
          dataType: "json",
          headers: {
            "X-CSRFToken": getCookie("csrftoken"), // Ambil CSRF token
          },
          success: function (data) {
            if (data.message) {
              var Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
              });
              Toast.fire({
                icon: "success",
                title: data.message,
              });
              $("#ajax-table tbody").html(data.html_data_list); // Perbarui tabel
            }
          },
          error: function (xhr, status, error) {
            Swal.fire({
              title: "Terjadi Kesalahan!",
              text: "Gagal mengubah status data.",
              icon: "error",
            });
          },
        });
      }
    });
  };

  // Fungsi untuk mendapatkan CSRF token dari cookie
  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== "") {
      const cookies = document.cookie.split(";");
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === name + "=") {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }

  // Event handler untuk Change Status
  $("#ajax-table").on("click", ".js-change-status", changeStatus);
});
