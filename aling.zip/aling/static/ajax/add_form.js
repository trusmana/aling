function show_modal(id) {
    jQuery('.az-modal-' + id).modal({
        backdrop: 'static',
        keyboard: true
    })
}

function hide_modal(id) {
    jQuery('.az-modal-' + id).modal('hide')
}

function show_loading() {
    jQuery(".az-loading").show()
}

function hide_loading() {
    jQuery(".az-loading").hide()
}

function clear(idform) {
    jQuery(".az-modal form#" + idform + " input").not(".x-hidden, :radio").val("");
    jQuery(".az-modal form#" + idform + " input:radio").prop('checked', false);
    jQuery(".az-modal form#" + idform + " select").not('.x-hidden').each(function(index, value) {
        if (jQuery(this).hasClass("select2-ajax")) {
            jQuery(this).val("").trigger("change")
        } else {
            jQuery(this).val(jQuery(this).find("option:first").val()).trigger("change")
        }
    });
    jQuery(".az-modal form#" + idform + " textarea").val("");
    var t_ckeditor = jQuery(".az-modal form#" + idform + " .ckeditor");
    jQuery(t_ckeditor).each(function() {
        var id_ckeditor = jQuery(this).attr('id');
        CKEDITOR.instances[id_ckeditor].setData('')
    });
    var filter_table = jQuery(".filter-tabel select");
    jQuery(filter_table).each(function() {
        var fil = jQuery(this).attr("fil");
        jQuery("#" + fil).val(jQuery("#f" + fil).val())
    });
    jQuery('#l_product_name').text('-');
    jQuery(".az-modal form#" + idform + " input[type='checkbox']").prop('checked', false);
    jQuery(".az-modal form#" + idform + " input[type='radio']").prop('checked', false);
    try {
        jQuery("input[data-role='tagsinput']").tagsinput('removeAll')
    } catch (err) {}
}

function edit(url, id, form, table_id, callback) {
    show_loading();
    clear(form);
    $.ajax({
        type: "POST",
        url: url,
        data: {
            id: id,
        },
        success: function(response) {
            var err_message = response.err_message;
            if (err_message != undefined) {
                bootbox.alert(err_message)
            } else {
                var f_input = jQuery('#' + form + ' input');
                var arr_ajax = [];
                var arr_azimage = [];
                jQuery.each(response[0], function(index, valu) {
                    jQuery('#' + index).not("[type='file'], [type='checkbox']").val(valu).trigger("change");
                    if (jQuery('#' + index).hasClass("format-number")) {
                        jQuery('#' + index).val(thousand_separator(jQuery('#' + index).val()))
                    }
                    if (jQuery('#' + index).hasClass("format-number-minus")) {
                        jQuery('#' + index).val(thousand_separator(jQuery('#' + index).val()))
                    }
                    if (jQuery('#' + index).hasClass("format-number-decimal")) {
                        var the_separator = jQuery("#" + index).attr('data-decimal');
                        if (the_separator == undefined) {
                            the_separator = 2
                        }
                        jQuery('#' + index).val(thousand_separator_decimal(jQuery('#' + index).val(), 2))
                    }
                    jQuery.each(jQuery("input[name='" + index + "']"), function(adata, bdata) {
                        if (jQuery(bdata).attr('type') == 'radio' || jQuery(bdata).attr('type') == 'checkbox') {
                            jQuery(bdata).prop('checked', false);
                            if (jQuery(bdata).val() == valu) {
                                jQuery(bdata).prop('checked', true)
                            }
                        }
                    });
                    try {
                        jQuery("#" + index + "[data-role='tagsinput']").tagsinput('removeAll');
                        jQuery("#" + index + "[data-role='tagsinput']").tagsinput('add', valu)
                    } catch (err) {}
                    var ajax_ = index;
                    if (ajax_.indexOf("ajax_") >= 0) {
                        arr_ajax.push(ajax_)
                    }
                    var azimage_ = index;
                    if (azimage_.indexOf("azimage_") >= 0) {
                        arr_azimage.push(azimage_)
                    }
                });
                if (arr_ajax.length > 0) {
                    jQuery.each(arr_ajax, function(index_arr, value_arr) {
                        var idajax = value_arr.replace("ajax_", "");
                        if (response[0][value_arr] != null) {
                            jQuery("#" + idajax + ".select2-ajax").append(new Option(response[0][value_arr], response[0][idajax], true, true)).trigger('change')
                        }
                    })
                }
                var t_area = jQuery("#" + form + ' .ckeditor');
                jQuery(t_area).each(function() {
                    var id_ckeditor = jQuery(this).attr('id');
                    CKEDITOR.instances[id_ckeditor].setData(response[0][id_ckeditor])
                });
                if (arr_azimage.length > 0) {
                    jQuery.each(arr_azimage, function(index_arr, value_arr) {
                        var idazimage = value_arr.replace("azimage_", "");
                        if (response[0][value_arr] != null) {
                            jQuery(".az-content-image-" + idazimage + "").attr('src', "https://azlaundry.azostech.com/azapp/application/azlaundry/demo/" + 'assets/images/member_photos/' + response[0][value_arr] + '?1725392428');
                            jQuery('.az-image-file-div-' + idazimage).hide()
                        } else {
                            jQuery(".az-content-image-" + idazimage + "").attr('src', "https://azlaundry.azostech.com/azapp/application/azlaundry/demo/" + 'assets/images/no-image.jpg');
                            jQuery('.az-image-file-div-' + idazimage).show()
                        }
                    })
                }
                jQuery(".modal-title span").text("Edit");
                callback(response);
                show_modal(table_id)
            }
            hide_loading()
        },
        error: function(response) {
            hide_loading()
        },
        dataType: "json"
    })
};

function save(url, form, vtable, callback, data) {
    show_loading();
    var formdata = new FormData();
    var txt_ckeditor = jQuery('#' + form + ' .ckeditor');
    jQuery(txt_ckeditor).each(function() {
        var id_ckeditor = jQuery(this).attr("id");
        CKEDITOR.instances[id_ckeditor].updateElement()
    });
    var data_file = jQuery('#' + form).find('input[type="file"]');
    jQuery(data_file).each(function(adata, bdata) {
        var file_id = jQuery(bdata).attr('id');
        var file_name = jQuery(bdata).attr('name');
        var file = jQuery(bdata)[0].files[0];
        if (file_name.length > 0) {
            file_id = file_name
        }
        formdata.append(file_id, file)
    });
    $.each(jQuery('#' + form).serializeArray(), function(a, b) {
        formdata.append(b.name, b.value)
    });
    if (!data) {
        data = []
    }
    jQuery.each(data, function(ke, va) {
        formdata.append(ke, jQuery(va).val())
    });
    $.ajax({
        url: url,
        data: formdata,
        processData: false,
        contentType: false,
        type: 'POST',
        dataType: "json",
        success: function(response) {
            hide_loading();
            if (response.sMessage != "") {
                var err_response = response.sMessage;
                err_response = err_response.replace(/\n/g, "<br>");
                bootbox.alert({
                    title: "Kesalahan",
                    message: err_response
                })
            } else {
                bootbox.alert({
                    title: "Sukses",
                    message: "Simpan data berhasil"
                });
                jQuery(".az-modal-" + vtable).modal("hide");
                var dtable = jQuery('#' + vtable).dataTable({
                    bRetrieve: true
                });
                dtable.fnDraw(false);
                callback(response)
            }
        },
        error: function(response) {
            console.log(response);
            hide_loading()
        }
    })
}

function remove(url, id, vtable, callback) {
    bootbox.confirm({
        title: "Hapus data",
        message: "Apakah anda yakin ingin menghapusnya?",
        callback: function(result) {
            if (result == true) {
                $.ajax({
                    url: url,
                    type: "post",
                    dataType: "json",
                    data: {
                        id: id
                    },
                    success: function(response) {
                        if (response.err_code > 0) {
                            bootbox.alert({
                                title: "Kesalahan",
                                message: response.err_message
                            })
                        } else {
                            var dtable = jQuery('#' + vtable).dataTable({
                                bRetrieve: true
                            });
                            dtable.fnDraw(false);
                            callback(response)
                        }
                    },
                    error: function(er) {
                        bootbox.alert({
                            title: "Kesalahan",
                            message: "Hapus data gagal " + er
                        })
                    }
                })
            }
        }
    })
}

function thousand_separatorx(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        return x.toString().replace(/\./g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }
}

function thousand_separator_ori(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        x = x.toString().replace(/\./g, '');
        var n = x.toString().split(",");
        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        return n.join(",")
    }
}
var format_number = ".";
var format_decimal = ",";
var db_format_decimal = "";
if (db_format_decimal == ".") {
    format_decimal = ".";
    format_number = ","
}

function thousand_separator(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        x = x.toString().replace(new RegExp('\\' + format_number, 'g'), '');
        var n = x.toString().split(format_decimal);
        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, format_number);
        return n.join(format_decimal)
    }
}

function thousand_separator_decimal_ori(x, y) {
    if (x == null) {
        return x
    }
    if (y == null) {
        y = 2
    }
    if (typeof x !== undefined) {
        if (x == '') {
            x = 0
        }
        new_x = parseFloat(x).toFixed(y);
        new_x = new_x.toString().replace(/\./g, ',');
        var n = new_x.toString().split(",");
        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        var ret = n.join(",");
        return ret
    }
}

function thousand_separator_decimal(x, y) {
    if (x == null) {
        return x
    }
    if (y == null) {
        y = 2
    }
    if (typeof x !== undefined) {
        if (x == '') {
            x = 0
        }
        new_x = parseFloat(x).toFixed(y);
        new_x = new_x.toString().replace(new RegExp('\\' + format_number, 'g'), format_decimal);
        var n = new_x.toString().split(format_decimal);
        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, format_number);
        var ret = n.join(format_decimal);
        return ret
    }
}

function get_thousand_separator_decimal(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        var x = x.toString().replace(/\./g, ',');
        return thousand_separator_decimal(x)
    }
}

function remove_separator(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        if (format_decimal == '.') {
            var new_x = x.toString().replace(/\,/g, '')
        } else {
            var new_x = x.toString().replace(/\./g, '');
            new_x = new_x.toString().replace(/\,/g, '.')
        }
        return new_x
    }
}

function remove_dot(x) {
    if (x == null) {
        return x
    }
    if (typeof x !== 'undefined') {
        return x.toString().replace(/\./g, '')
    }
}

function az_reload_csrf() {
    setTimeout(function() {
        jQuery('input[name=\"' + csrf_token_name + '\"]').val(jQuery.cookie(csrf_cookie_name))
    }, 1000)
}
jQuery(document).ready(function() {
    try {
        jQuery("select.select").select2()
    } catch (e) {}
    $.fn.modal.Constructor.prototype.enforceFocus = function() {};
    jQuery("body").append(jQuery(".az-modal"));
    jQuery('.az-modal').on('shown.bs.modal', function() {
        jQuery('input:text:visible:first', this).not('.x-hidden, .x-focus').focus()
    });
    jQuery(document).on('show.bs.modal', '.modal', function() {
        var zIndex = 1040 + (10 * jQuery('.modal:visible').length);
        $(this).css('z-index', zIndex);
        setTimeout(function() {
            jQuery('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack')
        }, 0)
    });
    jQuery(document).on('hidden.bs.modal', '.modal', function() {
        jQuery('.modal:visible').length && jQuery(document.body).addClass('modal-open')
    });
    jQuery("body").on("change", ".filter-table select", function() {
        var table_id = jQuery(".filter-tabel").attr("tid");
        var dtable = jQuery('#' + table_id).dataTable({
            bRetrieve: true
        });
        dtable.fnDraw(false)
    });
    jQuery('.az-form').on('keyup keypress', function(e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            if (event.target.tagName != 'TEXTAREA') {
                e.preventDefault();
                return false
            }
        }
    });
    var typingTimer;
    var doneTypingInterval = 4000;
    var config_interval = "";
    if (config_interval != "") {
        doneTypingInterval = config_interval
    }
    jQuery("body").on('keyup keydown', '.format-number', function(e) {
        jQuery(this).val(thousand_separator(jQuery(this).val()));
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 || (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault()
        }
    });
    jQuery("body").on('keydown keyup', '.format-number-decimal', function(e) {
        var the = jQuery(this);
        var decimal = jQuery(this).attr('data-decimal');
        if (decimal == undefined) {
            decimal = 2
        }
        clearTimeout(typingTimer);
        typingTimer = setTimeout(function() {
            var new_val = remove_separator(the.val());
            the.val(thousand_separator_decimal(new_val, decimal))
        }, doneTypingInterval);
        var key_decimal = [46, 8, 9, 27, 13];
        if (format_decimal == '.') {
            key_decimal.push(110);
            key_decimal.push(190)
        } else {
            key_decimal.push(188)
        }
        if ($.inArray(e.keyCode, key_decimal) !== -1 || (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault()
        }
    });
    jQuery("body").on('keyup keydown', '.format-number-minus', function(e) {
        jQuery(this).val(thousand_separator(jQuery(this).val()));
        if ($.inArray(e.keyCode, [189, 46, 8, 9, 27, 13, 190]) !== -1 || (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault()
        }
    });
    jQuery("body").on('keyup keydown', '.format-phone', function(e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 || (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault()
        }
    });
    jQuery(document).on('click', '.az-table tbody tr td', function(event) {
        var btn = jQuery(this).find('button');
        if (btn.length == 0) {
            jQuery(this).parents('tr').toggleClass('selected')
        }
    })
});
jQuery("body").on("click", ".hidden-menu-text", function() {
    jQuery("menu ul:eq(0)").slideToggle('fast');
    jQuery("menu .hidden-menu-text i").toggleClass("fa-caret-square-o-up fa-caret-square-o-down")
});
jQuery('.img-btn-language').click(function() {
    var lang = jQuery(this).attr('data-id');
    jQuery.ajax({
        url: app_url + 'home/change_language/' + lang,
        success: function(respond) {
            location.reload()
        },
    })
});
var selected_lang = "indonesian";
if (selected_lang == 'indonesian') {
    jQuery('.img-btn-language[data-id="id"]').css('opacity', 1);
    jQuery('.img-btn-language[data-id="en"]').css('opacity', 0.5)
} else {
    jQuery('.img-btn-language[data-id="id"]').css('opacity', 0.5);
    jQuery('.img-btn-language[data-id="en"]').css('opacity', 1)
}
jQuery("body").on("change", "#idoutlet", function() {
    jQuery("#idcustomer").val("").trigger("change")
});
jQuery('.btn-add-product-transaction').on('click', function() {
    new_transaction()
});
jQuery('.btn-add-detail').on('click', function() {
    add_detail()
});

function add_detail() {
    var new_numb = jQuery('.table-detail .detail-numb').length;
    new_numb++;
    var table = '<tr>';
    table += '<td><input type="hidden" name="idtransaction_detail[]" class="detail-idtransaction-detail"><button class="btn btn-danger btn-remove-row" data-id="transaction-detail" type="button"><i class="fa fa-remove"></i></button></td>';
    table += '<td><input readonly type="text" class="form-control detail-numb numb" value="' + new_numb + '"></td>';
    table += '<td><input type="text" name="detail_description[]" class="form-control detail-description"></td>';
    table += '<td><input type="number" class="form-control detail-qty txt-center" name="detail_qty[]"></td>';
    table += '</tr>';
    jQuery(".table-detail tbody").append(table);
    calc_total_qty()
}
calc_total_qty();
jQuery('body').on('keyup keydown change mouseup', '.detail-qty', function() {
    calc_total_qty()
});

function calc_total_qty() {
    var total_qty = 0;
    jQuery('.detail-qty').each(function(adata, bdata) {
        var detail_qty = jQuery(bdata).val() || 0;
        total_qty += parseInt(detail_qty)
    });
    jQuery('.txt-total-qty').text(total_qty)
}

function new_transaction() {
    var new_numb = jQuery('.table-transaction .numb').length;
    new_numb++;
    var table = '';
    table += '<tr>';
    table += '	<td><button class="btn btn-danger btn-remove-row" data-id="transaction" type="button"><i class="fa fa-remove"></i></button></td>';
    table += '	<td><input readonly type="text" class="form-control numb" value="' + new_numb + '"></td>';
    table += '	<td>';
    table += '		<input type="hidden" name="idtransaction[]" class="product-idtransaction">';
    table += '		<input type="hidden" name="idproduct[]" class="product-idproduct">';
    table += '		<div class="container-product-search">';
    table += '			<input readonly type="text" class="form-control product-name" placeholder="Search Product">';
    table += '			<button class="btn btn-default btn-search-product" type="button"><i class="fa fa-search"></i></button>';
    table += '		</div>';
    table += '	</td>';
    table += '	<td><input type="text" readonly class="form-control product-type"></td>';
    table += '	<td><input type="text" value="1,00" class="form-control product-qty format-number-decimal" name="qty[]"></td>';
    table += '	<td><input type="text" class="form-control product-price format-number-decimal" name="harga"></td>';
    table += '	<td><input type="text" value="0,00" class="form-control product-discount format-number-decimal" name="discount[]"></td>';
    table += '	<td><input type="text" value="0,00" class="form-control product-add-cost format-number-decimal" name="add_cost[]"></td>';
    table += '	<td><input type="text" value="0,00" class="form-control product-tax format-number-decimal" name="tax[]"></td>';
    table += '	<td><input type="text" value="0,00" class="form-control product-total format-number-decimal" readonly name="total[]"></td>';
    table += '</tr>';
    jQuery(".table-transaction tbody").append(table)
}
// jQuery('body').on('click', '.container-product-search', function() {
//     var index = jQuery('.container-product-search').index(jQuery(this));
//     if (jQuery('#idoutlet').val() == null) {
//         bootbox.alert('Harap pilih outlet terlebih dahulu')
//     } else {
//         jQuery('#product_selected').val(index);
//         show_modal('product')
//     }
// });
// jQuery('body').on('click', '.btn-choose-product', function() {
//     var idproduct = jQuery(this).attr('data-id');
//     var type = jQuery(this).attr('data-type');
//     var price = jQuery(this).attr('data-price');
//     var name = jQuery(this).attr('data-name');
//     var index = jQuery("#product_selected").val();
//     price = thousand_separator_decimal(price);
//     jQuery('.product-idproduct:eq(' + index + ')').val(idproduct);
//     jQuery('.product-type:eq(' + index + ')').val(type);
//     jQuery('.product-price:eq(' + index + ')').val(price);
//     jQuery('.product-name:eq(' + index + ')').val(name);
//     jQuery('.az-modal').modal('hide');
//     jQuery('.product-qty:eq(' + index + ')').focus();
//     calculate_total()
// });
jQuery('body').on('change keyup keydown', '.product-qty, .product-price, .product-tax, .product-add-cost, .product-discount, #info_discount, #info_add_cost, #info_tax, #info_pay, #info_discount_percent', function() {
    calculate_total()
});
calculate_total();

function calculate_total() {
    var info_total = 0;
    jQuery('.product-qty').each(function(adata, bdata) {
        var qty = jQuery(bdata).val() || 0;
        var price = jQuery('.product-price:eq(' + adata + ')').val() || 0;
        var discount = jQuery('.product-discount:eq(' + adata + ')').val() || 0;
        var add_cost = jQuery('.product-add-cost:eq(' + adata + ')').val() || 0;
        var tax = jQuery('.product-tax:eq(' + adata + ')').val() || 0;
        qty = remove_separator(qty);
        price = remove_separator(price);
        discount = remove_separator(discount);
        add_cost = remove_separator(add_cost);
        tax = remove_separator(tax);
        var total = (parseFloat(qty) * parseFloat(price)) - parseFloat(discount) + parseFloat(add_cost) + parseFloat(tax);
        info_total += total;
        total = thousand_separator_decimal(total);
        jQuery('.product-total:eq(' + adata + ')').val(total)
    });
    var info_discount = jQuery('#info_discount').val() || 0;
    var info_add_cost = jQuery('#info_add_cost').val() || 0;
    var info_tax = jQuery('#info_tax').val() || 0;
    info_discount = remove_separator(info_discount);
    info_add_cost = remove_separator(info_add_cost);
    info_tax = remove_separator(info_tax);
    var info_total_final = parseFloat(info_total) - parseFloat(info_discount) + parseFloat(info_add_cost) + parseFloat(info_tax);
    jQuery('#info_total').val(thousand_separator_decimal(info_total));
    jQuery('#info_total_final').val(thousand_separator_decimal(info_total_final));
    var pay = jQuery('#info_pay').val() || 0;
    pay = remove_separator(pay);
    var not_yet = parseFloat(pay) - info_total_final;
    if (not_yet > 0) {
        not_yet = 0
    } else {
        not_yet = Math.abs(not_yet)
    }
    jQuery('#info_not_yet_pay').val(thousand_separator_decimal(not_yet))
}

function calculate_percent(type) {
    var discount = remove_separator(jQuery('#info_' + type).val()) || 0;
    var total_transaction = remove_separator(jQuery('#info_total').val());
    var discount_percent = parseInt(discount) / parseInt(total_transaction) * 100;
    discount_percent = discount_percent || 0;
    jQuery('#info_' + type + '_percent').val(thousand_separator_decimal(discount_percent))
}

function calculate_discount(type) {
    var discount_percent = remove_separator(jQuery('#info_' + type + '_percent').val()) || 0;
    var total_transaction = remove_separator(jQuery('#info_total').val());
    var discount_total = parseInt(discount_percent) / 100 * total_transaction;
    discount_percent = discount_total;
    jQuery('#info_' + type).val(thousand_separator_decimal(discount_percent));
    calculate_total()
}
jQuery('#info_discount_percent').on('keyup keydown', function() {
    calculate_discount('discount')
});
jQuery('#info_discount').on('keyup keydown', function() {
    calculate_percent('discount')
});
jQuery('#info_tax_percent').on('keyup keydown', function() {
    calculate_discount('tax')
});
jQuery('#info_tax').on('keyup keydown', function() {
    calculate_percent('tax')
});
jQuery('body').on('change', '#idoutlet', function() {
    var dtable = jQuery('#product').dataTable({
        bRetrieve: true
    });
    dtable.fnDraw();
    jQuery('.table-transaction tbody').html('');
    new_transaction();
    calculate_total()
});
jQuery('body').on('click', '.btn-remove-row', function() {
    var the_table = jQuery(this).parents('table');
    var attr = jQuery(this).attr('data-id');
    if (attr == 'transaction') {
        id = 'product-idtransaction';
        field = 'x_transaction'
    } else {
        id = 'detail-idtransaction-detail';
        field = 'x_transaction_detail'
    }
    var old_val = jQuery('#' + field).val();
    var new_val = jQuery(this).parents('tr').find('.' + id).val();
    if (new_val.length > 0) {
        var val_remove = old_val + ',' + new_val;
        jQuery("#" + field).val(val_remove)
    }
    jQuery(this).parents('tr').remove();
    var numb = the_table.find('.numb');
    jQuery(numb).each(function(adata, bdata) {
        jQuery(bdata).val((adata + 1))
    });
    calculate_total();
    calc_total_qty()
});
jQuery('#btn_save_transaction').on('click', function() {
    save_transaction()
});
jQuery('#btn_save_print_transaction').on('click', function() {
    save_transaction('print')
});

function save_transaction(type) {
    show_loading();
    jQuery.ajax({
        url: app_url + 'sales_transaction/save',
        type: 'POST',
        dataType: 'JSON',
        data: jQuery('#form_transaction').serialize(),
        success: function(response) {
            hide_loading();
            if (response.err_code == 0) {
                bootbox.alert({
                    title: "Sukses",
                    message: "Transaksi Berhasil Disimpan",
                    callback: function() {
                        if (type == 'print') {
                            window.open(app_url + 'sales_transaction/invoice/?t=small&c=' + response.invoice, '_blank')
                        }
                        location.href = app_url + 'sales_transaction'
                    }
                })
            } else {
                bootbox.alert({
                    title: "Error",
                    message: response.err_message
                })
            }
        },
        error: function(response) {
            hide_loading()
        }
    })
}
get_edit();

function get_edit() {
    var is_edit = "add";
    var id = "";
    if (is_edit == 'edit' && id.length > 0) {
        jQuery.ajax({
            url: app_url + 'sales_transaction/get_edit',
            type: 'POST',
            dataType: 'JSON',
            data: {
                id: id
            },
            success: function(response) {
                if (response.err_code > 0) {
                    bootbox.alert({
                        title: "Kesalahan",
                        message: response.err_message,
                        callback: function() {
                            location.href = app_url + 'sales_transaction'
                        }
                    })
                } else {
                    jQuery.each(response.data, function(adata, bdata) {
                        jQuery('#' + adata).val(bdata);
                        if (jQuery('#' + adata).hasClass('format-number-decimal')) {
                            jQuery('#' + adata).val(thousand_separator_decimal(bdata))
                        }
                        var arr_ajax = [];
                        var ajax_ = adata;
                        if (ajax_.indexOf("ajax_") >= 0) {
                            arr_ajax.push(ajax_)
                        }
                        if (arr_ajax.length > 0) {
                            jQuery.each(arr_ajax, function(index_arr, value_arr) {
                                var idajax = value_arr.replace("ajax_", "");
                                if (response.data[value_arr] != null) {
                                    jQuery("#" + idajax + ".select2-ajax").append(new Option(response.data[value_arr], response.data[idajax], true, true)).trigger('change')
                                }
                            })
                        }
                    });
                    jQuery(".table-transaction tbody").html('');
                    jQuery.each(response.data_transaction, function(adata, bdata) {
                        new_transaction();
                        jQuery('.product-idtransaction').last().val(bdata.idtransaction);
                        jQuery('.product-idproduct').last().val(bdata.idproduct);
                        jQuery('.product-name').last().val(bdata.product_name);
                        jQuery('.product-type').last().val(bdata.product_type);
                        jQuery('.product-qty').last().val(thousand_separator_decimal(bdata.qty));
                        jQuery('.product-price').last().val(thousand_separator_decimal(bdata.price));
                        jQuery('.product-discount').last().val(thousand_separator_decimal(bdata.discount));
                        jQuery('.product-add-cost').last().val(thousand_separator_decimal(bdata.add_cost));
                        jQuery('.product-tax').last().val(thousand_separator_decimal(bdata.tax));
                        jQuery('.product-total').last().val(thousand_separator_decimal(bdata.total));
                        calculate_total()
                    });
                    jQuery(".table-detail tbody").html('');
                    jQuery.each(response.data_detail, function(adata, bdata) {
                        add_detail();
                        jQuery('.detail-idtransaction-detail').last().val(bdata.idtransaction_detail);
                        jQuery('.detail-description').last().val(bdata.detail_description);
                        jQuery('.detail-qty').last().val(bdata.detail_qty);
                        calc_total_qty()
                    });
                    check_pay()
                }
            },
            error: function(response) {}
        })
    }
}
jQuery('#btn_add_customer').on('click', function() {
    jQuery('.form-customer input').val(''); // Kosongkan input form
    jQuery('.form-customer textarea').val('');
    jQuery('.form-customer select').val('');
    jQuery('#customerModal').modal('show'); // Tampilkan modal
});
jQuery('#btn_add_customer').on('click', function() {
    var customerData = jQuery('.form-customer').serialize(); // Ambil data form modal

    // Kirim data ke server menggunakan AJAX
    jQuery.ajax({
        url: "/laundry/add_cus/",   // URL untuk menyimpan data customer        
        method: "POST",
        data: customerData,
        success: function(response) {
            // Tambahkan customer baru ke dropdown pelanggan
            var newCustomer = new Option(response.nama_customer, response.id, false, true);
            jQuery('#idcustomer').append(newCustomer).trigger('change');

            // Tutup modal setelah customer berhasil disimpan
            jQuery('#customerModal').modal('hide');
        },
        error: function(xhr) {
            // Tangani error
            alert("Error: " + xhr.responseText);
        }
    });
});


jQuery('body').on('change', '#pay', function() {
    check_pay()
});
check_pay();

function check_pay() {
    var pay = jQuery('#pay').val();
    if (pay == 'PAID') {
        jQuery('.container-pay-date').removeClass('hide')
    } else {
        jQuery('.container-pay-date').addClass('hide')
    }
}
jQuery(document).ready(function() {
    jQuery('#date').datetimepicker({
        format: 'DD-MM-YYYY HH:mm:ss',
    });
    jQuery('#duedate').datetimepicker({
        format: 'DD-MM-YYYY HH:mm:ss',
    });
    jQuery('#pay_date').datetimepicker({
        format: 'DD-MM-YYYY HH:mm:ss',
    });
    generate_table_product();

    function generate_table_product() {
        var total_column = [];
        var column = jQuery("#product thead tr:eq(0) th").length;
        for (var i = 0; i < column; i++) {
            total_column.push(null)
        }
        jQuery("#product").dataTable({
            "bServerSide": true,
            "sAjaxSource": app_url + 'data/get_data_product',
            "bFilter": true,
            "bProcessing": true,
            "bLengthChange": true,
            "bSort": true,
            "bSortCellsTop": true,
            "dom": '<"row"<"col-sm-6 col-sm-offset-6"f>> <"row"<"col-sm-12"tr>><"row"<"col-sm-5"l><"col-sm-7"p>><"row"<"col-sm-12"i>>',
            "bAutoWidth": false,
            "bPaginate": true,
            "bInfo": true,
            "pageLength": "10",
            "lengthMenu": [
                [10, 25, 50, 100, 200, 300, 500, -1],
                [10, 25, 50, 100, 200, 300, 500, "Semua"]
            ],
            "aoColumns": total_column,
            "columnDefs": [{
                "targets": "no-sort",
                "orderable": false,
                "order": []
            }],
            "fnServerParams": function(aoData) {
                jQuery("#product .form-filter").each(function() {
                    var id_filter = jQuery(this).attr("data-filter");
                    var clear_id_filter = id_filter.substring(2);
                    aoData.push({
                        "name": "cfilter[" + clear_id_filter + "]",
                        "value": jQuery(this).val()
                    })
                });
                jQuery(".form-top-filter-product .element-top-filter").each(function() {
                    var id_filter = jQuery(this).attr("data-id");
                    var value_filter = jQuery(this).val();
                    var con_value = "";
                    var tpwh = jQuery(this).attr("data-w");
                    if (tpwh == "true") {
                        if (value_filter != null) {
                            value_filter = "x~aztpwh~" + value_filter
                        }
                    }
                    jQuery(this).find(".con-element-top-filter").each(function() {
                        var pre = "";
                        if (con_value != "") {
                            pre = "~az~"
                        }
                        con_value += pre + jQuery(this).val()
                    });
                    if (con_value != "") {
                        value_filter = con_value
                    }
                    aoData.push({
                        "name": "topfilter[" + id_filter + "]",
                        "value": value_filter
                    })
                });
                aoData.push({
                    "name": "idoutlet",
                    "value": jQuery("#idoutlet").val()
                });
                aoData.push({
                    "name": "idcustomer",
                    "value": jQuery("#idcustomer").val()
                });
                jQuery("#product .form-filter").each(function() {
                    var id_filter = jQuery(this).attr("data-filter");
                    var clear_id_filter = id_filter.substring(2);
                    aoData.push({
                        "name": "cfilter[" + clear_id_filter + "]",
                        "value": jQuery(this).val()
                    })
                })
            },
            "drawCallback": function(settings) {
                var api = this.api();
                var json = api.ajax.json();
                callback_table_complete_product(json)
            },
            "language": {
                "sProcessing": "Processing...",
                "sLengthMenu": "Showing _MENU_ entries",
                "sZeroRecords": "No matching records found",
                "sInfo": "Showing _START_ s/d _END_ of _TOTAL_ Data",
                "sInfoEmpty": "Showing 0 s/d 0 of 0 Data",
                "sInfoFiltered": "(filtered from _MAX_ total entries)",
                "sInfoPostFix": "",
                "sSearch": "Search:",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "First",
                    "sPrevious": "Sebelumnya",
                    "sNext": "Selanjutnya",
                    "sLast": "Last"
                }
            }
        })
    }

    function callback_table_complete_product(json) {}
    var callback_edit_product = function(response) {};
    jQuery("body").on("click", ".btn-edit-product", function() {
        var id = jQuery(this).attr("data_id");
        edit(app_url + 'data/edit_data_product', id, "", "product", callback_edit_product);
        enfield()
    });
    jQuery("body").on("click", ".btn-view-product", function() {
        var id = jQuery(this).attr("data_id");
        edit(app_url + 'data/edit_data_product', id, "", "product", callback_edit_product);
        disfield()
    });

    function enfield() {
        jQuery("# input").prop("disabled", false);
        jQuery("# select").prop("disabled", false);
        jQuery("# textarea").prop("disabled", false);
        jQuery("# button").prop("disabled", false);
        jQuery(".btn-save-product").show()
    }

    function disfield() {
        jQuery("# input").prop("disabled", true);
        jQuery("# select").prop("disabled", true);
        jQuery("# textarea").prop("disabled", true);
        jQuery("# button").prop("disabled", true);
        jQuery(".btn-save-product").hide()
    }
    var callback_delete_product = function(response) {};
    jQuery("body").on("click", ".btn-delete-product", function() {
        var id = jQuery(this).attr("data_id");
        remove(app_url + 'data/delete_data_product', id, "product", callback_delete_product)
    });
    var callback_save_product = function(response) {};
    var callback_add_product = function() {};
    var data_save_product = {};
    jQuery("body").on("click", ".btn-save-product", function() {
        save(app_url + 'data/save_data_product', "", "product", callback_save_product, data_save_product)
    });
    jQuery("body").on("click", ".btn-add-product", function() {
        clear("");
        jQuery(".modal-title span").text("Tambah");
        show_modal("product");
        callback_add_product();
        enfield();
        jQuery(".az-image-container .az-image img").attr("src", base_url + "assets/images/no-image.jpg");
        jQuery(".az-image-file-div").show()
    });
    jQuery("#btn_filter_product").click(function() {
        var dtable = $("#product").dataTable({
            bRetrieve: true
        });
        dtable.fnDraw(false)
    });
    jQuery("#btn_top_filter_product").click(function() {
        var dtable = $("#product").dataTable({
            bRetrieve: true
        });
        dtable.fnDraw(false)
    });
    jQuery(document).on("click", ".az-table#product tbody tr td", function(event) {
        var btn = jQuery(this).find("button");
        if (btn.length == 0) {
            var selected = check_table_product();
            init_selected_table_product()
        }
    });
    jQuery(".btn-select-all-product").on("click", function() {
        sel_un_all_product("select")
    });
    jQuery(".btn-unselect-all-product").on("click", function() {
        sel_un_all_product("unselect")
    });
    jQuery(".az-table#product").on("draw.dt", function() {
        init_selected_table_product()
    });
    jQuery(document).on("hidden.bs.modal", ".modal", function() {
        sel_un_all_product()
    });
    jQuery(".btn-delete-selected-product").on("click", function() {
        var id_delete = check_table_product();
        remove(app_url + 'data/delete_data_product', id_delete, "product", callback_delete_product)
    });
    jQuery(".azcrud-container-show-hide-product").on("click", function() {
        jQuery(".form-top-filter-body-product").slideToggle("fast");
        jQuery(".form-top-filter-hide-product").find(".fa").toggleClass("fa-chevron-circle-down fa-chevron-circle-up")
    });
    jQuery(".az-product").on("click", function() {
        jQuery(".form-top-filter-body-product").slideToggle("fast");
        jQuery(this).find(".fa").toggleClass("fa-chevron-circle-down fa-chevron-circle-up")
    });
    jQuery("#product_filter input").attr("placeholder", "");

    function init_selected_table_product() {
        var selected = check_table_product();
        var btn_hide = jQuery(".btn-select-all-product, .btn-unselect-all-product, .btn-delete-selected-product, .selected-data-product");
        if (selected.length > 0) {
            btn_hide.show()
        } else {
            btn_hide.hide()
        }
    }

    function check_table_product() {
        var table_select = jQuery(".az-table#product tbody tr.selected");
        var arr_delete = [];
        table_select.each(function() {
            var check_data = jQuery(this).find(".btn-delete-product").attr("data_id");
            if (typeof check_data != "undefined") {
                arr_delete.push(check_data)
            }
        });
        jQuery(".selected-data-product").text(arr_delete.length + " Data Terpilih");
        return arr_delete
    }

    function sel_un_all_product(type) {
        if (type == "select") {
            jQuery(".az-table#product tbody tr").addClass("selected")
        } else {
            jQuery(".az-table#product tbody tr").removeClass("selected")
        }
        init_selected_table_product()
    }
    jQuery("#idcidoutlet").select2({
        placeholder: "~ Pilih Outlet ~",
        allowClear: true,
        minimumInputLength: 0,
        ajax: {
            url: "https://azlaundry.azostech.com/data/get_outlet",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    term: params.term,
                    page: params.page || 1,
                    parent: jQuery("#").val(),
                }
            },
            cache: true
        }
    });
    jQuery("#idoutlet").select2({
        placeholder: "~ Pilih Outlet ~",
        allowClear: true,
        minimumInputLength: 0,
        ajax: {
            url: "https://azlaundry.azostech.com/data/get_outlet",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    term: params.term,
                    page: params.page || 1,
                    parent: jQuery("#").val(),
                }
            },
            cache: true
        }
    });
    jQuery("#idcustomer").select2({
        placeholder: "~ Pilih Pelanggan ~",
        allowClear: true,
        minimumInputLength: 0,
        ajax: {
            url: "https://azlaundry.azostech.com/data/get_customer",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    term: params.term,
                    page: params.page || 1,
                    parent: jQuery("#idoutlet").val(),
                }
            },
            cache: true
        }
    });
});