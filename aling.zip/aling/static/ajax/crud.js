$(function () {
    // <-- modal Create Edit Untuk Menampilakan Modal
    var loadForm = function () {
      var btn = $(this);       
        $.ajax({
          url: btn.attr("data-url"),
          type: 'get',
          dataType: 'json',
          success: function (data) {
            $("#modal-data .modal-content").html(data.html_form);
            $("#modal-data").modal("show");
          },
          error: function (xhr, status, error) {
            var Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 3000
            });
            Toast.fire({
              icon: 'warning',
              title: 'Cek Kembali Parameter Atau Data Anda !!!'
            });
          }
        });
    };    
    // <-- modal Create Edit Untuk menyimpan ke data base 
    var saveForm = function () {
      var form = $(this);
      $.ajax({
        url: form.attr("action"),
        data: form.serialize(),
        type: form.attr("method"),
        dataType: 'json',
        success: function (data) {    
          if (data.form_is_valid) {
            $("#ajax-table tbody").html(data.html_data_list);
            var Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 3000
            });
            Toast.fire({
              icon: 'warning',
              title: 'Data Berhasil Di Simpan '
            });
            $("#modal-data").modal("hide");
          }
          else {
            $("#modal-data .modal-content").html(data.html_form);
          }
        }
      });
    return false;
   };
  // Create Data
  $(".js-create-data").click(loadForm);
  $("#modal-data").on("submit", ".js-create-form",saveForm);
  // Edit Data
  $("#ajax-table").on("click", ".js-edit-data", loadForm);
  $("#modal-data").on("submit", ".js-edit-form",saveForm);
  // Delete book
  $("#ajax-table").on("click", ".js-delete-data", loadForm);
  $("#modal-data").on("submit", ".js-delete-form", saveForm);
  
});

