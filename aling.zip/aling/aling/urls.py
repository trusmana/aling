from django.contrib import admin
from django.urls import path,include
from django.views.static import serve
from django.conf import settings
from django.conf.urls.static import static

from apps.accounts import views as vs

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',vs.index,name="index"),
    path('accounts/',include('apps.accounts.urls')),
    path('customer/',include('apps.customer.urls')),
    path('cabang/',include('apps.cabang.urls')),

    path('barang/',include('appayam.barang.urls')),
    path('trans_out/',include('appayam.transaksi.urls')),
]

urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)