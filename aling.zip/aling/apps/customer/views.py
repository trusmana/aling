from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from django.shortcuts import render, get_object_or_404, redirect
from django.conf import settings
from django.http import JsonResponse
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator
from django.db.models import Q
from apps.customer import models as ml
from apps.customer import forms as fo

#####Crud Customer
@login_required(login_url=settings.LOGIN_URL)
def CustomerListView(request):
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = ml.Customer.objects.filter(Q(nama_customer__icontains=query) | Q(kode_pelanggan__icontains=query) ).order_by('id')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'customer/menu_customer.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100]  # Daftar opsi entri yang tersedia
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'customer/customer_list.html',context)

def save_data_form(request,user,form, template_name):
    data = dict()
    if request.method == 'POST':
        if form.is_valid():
            js = form.save(commit=False)
            js.cu = user
            js.status = True            
            js.save()
            data['form_is_valid'] = True
            datas = ml.Customer.objects.filter(status__isnull=False).order_by('-id')
            data['html_data_list'] = render_to_string('customer/menu_customer.html', {'datas': datas})
        else:
            data['form_is_valid'] = False
    context = {'form': form}
    data['html_form'] = render_to_string(template_name, context, request=request)
    return JsonResponse(data)

@login_required(login_url=settings.LOGIN_URL)
def add_customer(request):###### Create Data Customer
    user = request.user
    if request.method == 'POST':
        form = fo.CustomerForm(request.POST)
    else:
        form = fo.CustomerForm()
    return save_data_form(request,user, form, 'customer/create_customer.html')


@login_required(login_url=settings.LOGIN_URL)
def edit_customer(request,id): #### edit data customer
    user = request.user
    tb = get_object_or_404(ml.Customer,id=id)
    if request.method == 'POST':
        form = fo.CustomerForm(request.POST, instance=tb)
    else:
        form = fo.CustomerForm(instance=tb)
    return save_data_form(request,user, form,'customer/edit_customer.html')


@login_required(login_url=settings.LOGIN_URL)
def customer_delete(request, id):
    datas = get_object_or_404(ml.Customer, pk=id)
    data = dict()
    if request.method == 'POST':
        datas.delete()
        data['form_is_valid'] = True
        datas = ml.Customer.objects.all()
        data['html_data_list'] = render_to_string('customer/menu_customer.html', {'datas': datas})
    else:
        context = {'datas': datas}
        data['html_form'] = render_to_string('customer/customer_delete.html',context,request=request,)
    return JsonResponse(data)