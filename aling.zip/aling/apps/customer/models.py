from django.db import models
from django.dispatch import receiver
from django.utils import timezone
from django.db.models.signals import pre_save

from apps.accounts.models import AccountsUser as User


class Customer(models.Model):
    nama_customer = models.CharField(max_length=50,null=True)
    address = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15)
    kode_pelanggan = models.CharField( max_length=50,unique=True,null=True)
    cdate = models.DateField(auto_now_add=True,null=True)
    status = models.BooleanField(default=True,null=True,blank=True)
    cu = models.ForeignKey(User, related_name='cu_customer',blank=True, null=True,on_delete=models.CASCADE)
    
    def __str__(self):
        return f"{self.nama_customer}"
    
@receiver(pre_save, sender=Customer)
def auto_generate_number(sender, instance, **kwargs):
    if not instance.cdate:
        instance.cdate = timezone.now()  # Atur cdate secara manual jika belum di-set

    if not instance.kode_pelanggan:
        year = instance.cdate.year
        month = instance.cdate.month
        day = instance.cdate.day

        latest_outlet = Customer.objects.filter(cdate__year=year, cdate__month=month).order_by('-kode_pelanggan').first()

        if latest_outlet:
            latest_number = int(latest_outlet.kode_pelanggan.split('-')[1])
            new_number = latest_number + 1
        else:
            new_number = 1

        instance.kode_pelanggan = f"{year}{month:02d}{day:02d}-{new_number:03d}"

