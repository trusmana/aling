from django.urls import path,include

from apps.customer import views as vc

urlpatterns = [
    path('customer-list/', vc.CustomerListView, name='customer_list'),
    path('customer/create/', vc.add_customer, name='customer_add'),
    path('customer/edit/<int:id>/', vc.edit_customer, name='e-customer'),
    path('customer/del/<int:id>/', vc.customer_delete, name='d-customer'),
]
