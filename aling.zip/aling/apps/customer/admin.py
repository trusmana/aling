from django.contrib import admin
from apps.customer import models as cm


admin.site.register(cm.Customer)