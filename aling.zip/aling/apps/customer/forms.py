from django import forms
from apps.customer import models as mo

class CustomerForm(forms.ModelForm):
    class Meta:
        model = mo.Customer
        fields = ['nama_customer', 'address', 'phone_number']
        widgets = {
            'nama_customer': forms.TextInput(attrs={'class': 'form-control col-5'}),
            'address': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            
        }
