from django.contrib import admin

from apps.cabang import models as mc


admin.site.register(mc.Jenis_outlet)
admin.site.register(mc.Outlet)
