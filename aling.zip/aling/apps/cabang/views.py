from django.contrib.auth.decorators import login_required,user_passes_test
from django.template.loader import render_to_string
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q
from apps.cabang import models as ml
from apps.cabang import forms as fo

#####Crud Outlet

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def OutletListView(request):
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = ml.Outlet.objects.filter(Q(nama_outlet__icontains=query) | Q(kode_outlet__icontains=query) ).order_by('id')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'outlet/menu_outlet.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100]  # Daftar opsi entri yang tersedia
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'outlet/outlet_list.html',context)

def save_data_form(request,user,form, template_name):
    data = dict()
    if request.method == 'POST':
        if form.is_valid():
            js = form.save(commit=False)
            js.cu = user
            js.status = True            
            js.save()
            data['form_is_valid'] = True
            datas = ml.Outlet.objects.filter(status__isnull=False).order_by('-id')
            data['html_data_list'] = render_to_string('outlet/menu_outlet.html', {'datas': datas})
        else:
            data['form_is_valid'] = False
    context = {'form': form}
    data['html_form'] = render_to_string(template_name, context, request=request)
    return JsonResponse(data)


@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def OutletCreateView(request):###### Create Data outlet
    user = request.user
    if request.method == 'POST':
        form = fo.OutletForm(request.POST)
    else:
        form = fo.OutletForm()
    return save_data_form(request,user, form, 'outlet/create_outlet.html')

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def edit_outlet(request,id): #### edit data outlet
    user = request.user
    tb = get_object_or_404(ml.Outlet,id=id)
    if request.method == 'POST':
        form = fo.OutletForm(request.POST, instance=tb)
    else:
        form = fo.OutletForm(instance=tb)
    return save_data_form(request,user, form,'outlet/edit_outlet.html')

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def outlet_delete(request, id):
    datas = get_object_or_404(ml.Outlet, pk=id)
    data = dict()
    if request.method == 'POST':
        datas.delete()
        data['form_is_valid'] = True
        datas = ml.Outlet.objects.all()
        data['html_data_list'] = render_to_string('outlet/menu_outlet.html', {'datas': datas})
    else:
        context = {'datas': datas}
        data['html_form'] = render_to_string('outlet/outlet_delete.html',context,request=request,)
    return JsonResponse(data)

##########Jenis Outlet
@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def JenisOutlet(request):
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = ml.Jenis_outlet.objects.filter(Q(nama_outlet__icontains=query) ).order_by('id')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'jenis_outlet/menu_jenis_outlet.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100]  # Daftar opsi entri yang tersedia
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'jenis_outlet/jenis_outlet_list.html',context)

def save_data_jenis_otlet(request,user,form, template_name):
    data = dict()
    if request.method == 'POST':
        if form.is_valid():
            js = form.save(commit=False)
            js.cu = user
            js.status = True            
            js.save()
            data['form_is_valid'] = True
            datas = ml.Jenis_outlet.objects.all().order_by('-id')
            data['html_data_list'] = render_to_string('jenis_outlet/menu_jenis_outlet.html', {'datas': datas})
        else:
            data['form_is_valid'] = False
    context = {'form': form}
    data['html_form'] = render_to_string(template_name, context, request=request)
    return JsonResponse(data)



@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def JenisOutletCreate(request):###### Create Data outlet
    user = request.user
    if request.method == 'POST':
        form = fo.JenisOutletForm(request.POST)
    else:
        form = fo.JenisOutletForm()
    return save_data_jenis_otlet(request,user, form, 'jenis_outlet/create_jenis_outlet.html')

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def edit_jenis_outlet(request,id): #### edit data outlet
    user = request.user
    tb = get_object_or_404(ml.Jenis_outlet,id=id)
    if request.method == 'POST':
        form = fo.JenisOutletForm(request.POST, instance=tb)
    else:
        form = fo.JenisOutletForm(instance=tb)
    return save_data_jenis_otlet(request,user, form,'jenis_outlet/edit_jenis_outlet.html')


@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def joutlet_delete(request, id):
    datas = get_object_or_404(ml.Jenis_outlet, pk=id)
    data = dict()
    if request.method == 'POST':
        datas.delete()
        data['form_is_valid'] = True
        datas = ml.Jenis_outlet.objects.all()
        data['html_data_list'] = render_to_string('jenis_outlet/menu_jenis_outlet.html', {'datas': datas})
    else:
        context = {'datas': datas}
        data['html_form'] = render_to_string('jenis_outlet/joutlet_delete.html',context,request=request,)
    return JsonResponse(data)
##########Jenis Outlet

