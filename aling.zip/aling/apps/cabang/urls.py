from django.urls import path

from apps.cabang import views as vc
from apps.customer import views as cv

urlpatterns = [
    path('outlets/', vc.OutletListView, name='outlet_list'),
    path('add_outlets/', vc.OutletCreateView, name='outlet_add'),
    path('e_outlet/<int:id>/',vc.edit_outlet,name='e-outlet'),
    path('d_outlet/<int:id>/',vc.outlet_delete,name='d-outlet'),

    path('jenisoutlets/', vc.JenisOutlet, name='jenis_outlet_list'),
    path('add_joutlets/', vc.JenisOutletCreate, name='joutlet_add'),
    path('e_jenis_outlet/<int:id>/',vc.edit_jenis_outlet,name='e-jenisoutlet'),
    path('d_joutlet/<int:id>/',vc.joutlet_delete,name='d-joutlet'),

    path('customer_lets/', cv.CustomerListView, name='customer_list'),
    path('add_customer/', cv.add_customer, name='customer_add'),
    path('e_custoemer/<int:id>/',cv.edit_customer,name='e-customer'),
    path('d_customer/<int:id>/',cv.customer_delete,name='d-customer'),
]
