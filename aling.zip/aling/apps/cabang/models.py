from django.db import models
from django.dispatch import receiver
from django.db.models.signals import pre_save

class Jenis_outlet(models.Model):
    nama= models.CharField(max_length=50)    

    class Meta:
        verbose_name = ("Jenis_outlet")
        verbose_name_plural = ("Jenis_outlets")

    def __str__(self):
        return self.nama


class Outlet(models.Model):
    kode_outlet = models.CharField( max_length=50,unique=True,null=True,blank=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE,blank=True, null=True)
    jenis_outlet = models.ForeignKey(Jenis_outlet, on_delete=models.CASCADE,null=True,blank=True)
    nama_outlet = models.CharField( max_length=50)
    address = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15)
    cdate = models.DateField(auto_now_add=True)
    status = models.BooleanField(default=True,null=True,blank=True)

    def __str__(self):
        return f"Kode {self.kode_outlet} Nama {self.nama_outlet}"
    
@receiver(pre_save, sender=Outlet)
def generate_kode_outlet(sender, instance, **kwargs):
    if not instance.kode_outlet:  # Jika kode_outlet belum ada, generate kode baru
        jenis_outlet_id = instance.jenis_outlet.id

        # Cari outlet terakhir berdasarkan jenis_outlet yang sama
        latest_outlet = Outlet.objects.filter(jenis_outlet=instance.jenis_outlet).order_by('id').last()

        if latest_outlet:
            # Pisahkan bagian terakhir kode_outlet dan tambahkan 1
            latest_number = int(latest_outlet.kode_outlet.split('-')[1])
            new_number = latest_number + 1
        else:
            # Jika belum ada outlet sebelumnya, mulai dari 1
            new_number = 1

        # Generate kode_outlet dengan format "id_jenis_outlet-new_number"
        instance.kode_outlet = f"{jenis_outlet_id}{new_number:03d}"
