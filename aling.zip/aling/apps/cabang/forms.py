from django import forms
from apps.cabang import models as mo

class OutletForm(forms.ModelForm):
    class Meta:
        model = mo.Outlet
        fields = ['nama_outlet', 'address', 'phone_number','parent','jenis_outlet']
        widgets = {
            'nama_outlet': forms.TextInput(attrs={'class': 'form-control col-5'}),
            'address': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'parent': forms.Select(attrs={'class': 'form-control select2'}),
            'outlet': forms.Select(attrs={'class': 'form-control select2'}),
        }

class JenisOutletForm(forms.ModelForm):
    class Meta:
        model = mo.Jenis_outlet
        fields = ['nama']
        widgets = {
            'nama': forms.TextInput(attrs={'class': 'form-control'}),
            
        }