from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
from django.contrib.auth.models import  Group
from PIL import Image
from django.utils import timezone

from apps.cabang import models as ot

class AccountsUser(AbstractUser):
    email = models.EmailField(('email address'),unique = True)
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.email

class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to="avatar", blank= True,default='avatar/user.png')
    bio = models.CharField(null=True,blank=True, max_length=250) 
    is_banned = models.BooleanField(default=False)
    jumlah_banned = models.IntegerField(blank=True, null=True, default=0)
    last_password_change = models.DateTimeField(default=timezone.now) ###### Fungsi Periode Password
    cabang = models.ForeignKey(ot.Outlet, on_delete=models.CASCADE,null=True)
    
    def __str__(self):
        return self.user.username

    def save(self):
        super().save()

        img = Image.open(self.avatar.path) # Open image

        # resize image
        if img.height > 300 or img.width > 300:
            output_size = (250, 250)
            img.thumbnail(output_size) # Resize image
            img.save(self.avatar.path)
