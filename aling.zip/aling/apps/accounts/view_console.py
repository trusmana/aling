from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from .models import AccountsUser, Profile
from .forms_console import AccountsUserForm, ProfileForm

# Create
@login_required(login_url=settings.LOGIN_URL)
def create_user_profile(request):
    if request.method == 'POST':
        user_form = AccountsUserForm(request.POST)
        profile_form = ProfileForm(request.POST, request.FILES)

        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password1'])  # Hash the password
            user.save()

            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()

            user_form.save_m2m()  # For saving many-to-many fields like groups
            messages.success(request, 'Data berhasil!')    
            return redirect('user_profile_list')
    else:
        user_form = AccountsUserForm()
        profile_form = ProfileForm()

    return render(request, 'profile/user_profile_form.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })

# Read (List)
@login_required(login_url=settings.LOGIN_URL)
def user_profile_list(request):
    users = AccountsUser.objects.all()
    profiles = Profile.objects.all()

    # Gabungkan users dan profiles menggunakan zip di sini
    users_profiles = zip(users, profiles)

    context = {
        'users_profiles': users_profiles,
    }
    return render(request, 'profile/user_profile_list.html', context)

# Update
@login_required(login_url=settings.LOGIN_URL)
def update_user_profile(request, user_id):
    user = get_object_or_404(AccountsUser, id=user_id)
    profile = Profile.objects.get(user=user)

    if request.method == 'POST':
        user_form = AccountsUserForm(request.POST, instance=user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Data berhasil Diperbaharui!')    
            return redirect('user_profile_list')
    else:
        user_form = AccountsUserForm(instance=user)
        profile_form = ProfileForm(instance=profile)

    return render(request, 'profile/user_profile_form.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })

# Delete
@login_required(login_url=settings.LOGIN_URL)
def delete_user_profile(request, user_id):
    user = get_object_or_404(AccountsUser, id=user_id)
    profile = get_object_or_404(Profile, user=user)
    
    if request.method == 'POST':
        user.delete()
        profile.delete()
        return redirect('user_profile_list')

    return render(request, 'profile/user_profile_confirm_delete.html', {
        'user': user,
        'profile': profile
    })
