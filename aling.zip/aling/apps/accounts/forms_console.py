from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import AccountsUser, Profile

class AccountsUserForm(UserCreationForm):
    class Meta:
        model = AccountsUser
        fields = ['email', 'username', 'first_name', 'last_name', 'password1', 'password2', 'groups']
        # widgets = {
        #     'groups': forms.Select(attrs={'class': 'form-control select2'}),
        # }

    def __init__(self, *args, **kwargs):
        super(AccountsUserForm, self).__init__(*args, **kwargs)
        # Jika instance ada (edit mode), nonaktifkan validasi unik username
        if self.instance.pk:
            self.fields['username'].validators = []

    def clean_username(self):
        # Cek apakah username diubah dan unik
        username = self.cleaned_data.get('username')
        if AccountsUser.objects.filter(username=username).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Seorang pengguna dengan nama pengguna tersebut sudah ada.")
        return username


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['avatar', 'bio', 'is_banned', 'jumlah_banned', 'cabang']
        # widgets = {
        #     'outlet': forms.Select(attrs={'class': 'form-control select2'}),
        # }

