from django import forms
from django.contrib.auth.forms import UserCreationForm,UserChangeForm
from django.contrib.auth.models import User
from .models import AccountsUser,Profile

class LoginForm(forms.Form):
    email = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "Enter Email",
                "class": "form-control input-text  form-control-lg active"
            }
        ))
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "Enter Password",
                "class": "form-control input-text input-text--primary-style form-control-lg"
            }
        ))

# Create a UserUpdateForm to update username and email
class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = AccountsUser
        fields = ['username', 'email']

# Create a ProfileUpdateForm to update image
class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['avatar', 'bio',]

class AccountUserCreationForm(UserCreationForm):
    class Meta:
        model = AccountsUser
        fields = ('email',)

class AccountUserChangeForm(UserChangeForm):
    class Meta:
        model = AccountsUser
        fields = ('email',)