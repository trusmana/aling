from django.urls import path
from apps.accounts import views as av
from apps.accounts import view_console as cv

urlpatterns = [
    path('login/',av.login_view,name='login'),
    path("logout/", av.logout_view, name="logout"),
    path('profile/',av.detail_profile, name='detail_profile'),
    path('profile/edit/',av.edit_profile, name='edit_profile'),
    path('profile/edit_password/',av.edit_password, name='edit_password'),
    path('log400/', av.log_view_400, name='log_view_400'),
    path('log500/', av.log_view_500, name='log_view_500'),

    path('user_profiles/', cv.user_profile_list, name='user_profile_list'),
    path('user_profiles/create/', cv.create_user_profile, name='create_user_profile'),
    path('user_profiles/<int:user_id>/update/', cv.update_user_profile, name='update_user_profile'),
    path('user_profiles/<int:user_id>/delete/', cv.delete_user_profile, name='delete_user_profile'),
]