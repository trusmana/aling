from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.conf import settings
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.utils import timezone
import os

from apps.accounts import forms as fa
from apps.accounts import models as maa

@login_required(login_url=settings.LOGIN_URL)
def index(request):
    profile = request.user.profile
    days_since_last_change = (timezone.now() - profile.last_password_change).days
    expiry_days = 7  # Batas waktu password kadaluarsa (7 hari)
    warning_days = 1  # Waktu peringatan
    remaining_days = expiry_days - days_since_last_change  # Hitung sisa hari

    password_change_warning = days_since_last_change >= expiry_days - warning_days
    
    context = {
        'profile': profile,
        'password_change_warning': password_change_warning,
        'remaining_days': remaining_days,  # Sisa hari untuk kadaluarsa password
    }
    return render(request,'accounts/index.html',context)

@login_required(login_url=settings.LOGIN_URL)
def detail_profile(request):
    data = request.user.profile
    return render(request,'accounts/detail_profile.html',{'data':data,})



@login_required(login_url=settings.LOGIN_URL)
def edit_profile(request):
    profile_user = request.user.profile

    # Form untuk Profile Update
    if request.method == 'POST':
        p_form = fa.ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)
        
        if p_form.is_valid():
            p_form.save()
            messages.success(request, 'Profil Anda telah diperbarui!')
            return redirect('detail_profile')          
    else:
        p_form = fa.ProfileUpdateForm(instance=request.user.profile)        
    context = {
        'p_form': p_form,
        'data': profile_user
    }
    return render(request, 'accounts/edit_profile.html',context)


@login_required(login_url=settings.LOGIN_URL)
def edit_password(request):
    profile_user = request.user.profile
    if request.method == 'POST':
        password_form = PasswordChangeForm(user=request.user, data=request.POST)
        
        if password_form.is_valid():
            user = password_form.save()
            update_session_auth_hash(request, user)  # Agar user tidak logout setelah mengganti password
            user.profile.last_password_change = timezone.now()  # Update waktu password diganti
            user.profile.save()
            messages.success(request, 'Password Anda telah diperbarui!')
            return redirect('detail_profile')

    else:
        password_form = PasswordChangeForm(user=request.user)

    context = {
        'password_form': password_form,'data': profile_user,
    }
    return render(request, 'accounts/edit_password.html', context)

def login_view(request):
    form = fa.LoginForm(request.POST or None)
    msg = None
    if request.method == "POST":
        if form.is_valid():
            email = form.cleaned_data.get("email")
            password = form.cleaned_data.get("password")
            user = authenticate(email=email, password=password)
            #messages.success(request, 'Dilarang Keras Menggunakan User Orang Lain')   
            if user is not None:
                login(request, user)
                return redirect("/")
            else:    
                msg = 'Username Password tidak cocok' 
    return render(request, "accounts/login.html", {"form": form, "msg" : msg})


def logout_view(request):
    logout(request)
    return redirect('/')


def custom_404(request, exception):
    return render(request, 'accounts/404.html', status=404)

def custom_500(request):
    return render(request, 'accounts/500.html', status=500)

def log_view_400(request):
    #log_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'django_404.log')
    log_file_path ='django_error.log'
    log_content = ''
    
    try:
        with open(log_file_path, 'r') as f:
            log_content = f.readlines()
    except FileNotFoundError:
        log_content = ["Log file not found."]

    context = {
        'log_content': log_content,
    }
    
    return render(request, 'accounts/log_view_400.html', context)


def log_view_500(request):
    # log_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'django_error.log')
    log_file_path ='django_error.log'
    log_content = ''
    
    try:
        with open(log_file_path, 'r') as f:
            log_content = f.readlines()
    except FileNotFoundError:
        log_content = ["Log file not found."]

    context = {
        'log_content': log_content,
    }
    
    return render(request, 'accounts/log_view_500.html', context)
