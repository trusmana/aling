from django.urls import path

from appayam.transaksi import views as tv
from appayam.transaksi import views_pusat as tvp


urlpatterns = [
    ####Outlet
    path('daftar_pesanan/', tv.daftarpemesanan, name='data_pesanan'),
    path('daftar_pesanan_kiriman_pusat/', tv.daftarpemesanan_kirim_pusat, name='data_pesanan_kiriman_hub'),
    path('get-trans-pesan/', tv.addpesan, name='add-trans-pesan'),
    path('transaksi_customer/create/', tv.add_customer_trans, name='add_pelanggan_transaksi'),
    ### Stok
    path("satuan-barang-modal/", tv.satuanbarang_modal_ajax, name="satuan_modal_aja") ,
    path('satuan-barang/satuan_datatable/', tv.item_datatable_satuan, name='item_datatable_satuan'),###### datatable json
    path('d-change-status/<int:pk>/', tv.change_status, name='change_status'),
    ####Pusat
    path('daftar_pesanan_pusat_approve/', tvp.daftarpemesanan_approve, name='data_pesanan_approve'),
    path('daftar_pesanan_pusat/', tvp.daftarpemesanan_proses, name='data_pesanan_pusat'),
    path('export_data/',tvp.export_pemesanan_excel,name='export_pemesanan_excel'),

    ####Pusat Kirim
    path('daftar_pesanan_kirim/', tvp.daftarpemesanan_kirim, name='data_pesanan_kirim'),
    path('update-jumlah-dikirim/', tvp.update_jumlah_dikirim, name='update_jumlah_dikirim'),
    path('download_pdf/<int:pesanan_id>/', tvp.download_pdf_per_outlet, name='download_pdf_per_outlet'),

]
