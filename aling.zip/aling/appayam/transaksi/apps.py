from django.apps import AppConfig


class TransaksiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appayam.transaksi'
