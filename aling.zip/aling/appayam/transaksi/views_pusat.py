from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required,user_passes_test
from django.conf import settings
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.http import HttpResponseRedirect,JsonResponse
from django.urls import reverse
from django.utils.text import slugify
from django.db.models import Q
from django.core.paginator import Paginator
from django.forms import modelformset_factory,formset_factory
import io,xlsxwriter,os
import datetime
from django.http import HttpResponse
from datetime import date
from reportlab.pdfgen import canvas

from reportlab.lib.pagesizes import mm

from appayam.transaksi import models as tm
from apps.customer import models as cm
from appayam.barang import models as bm
from appayam.transaksi import forms as tf
from appayam.barang import forms as fbm
from apps.customer import forms as cf

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser)
def daftarpemesanan_approve(request):
    user = request.user
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    # object_list = tm.ItemPenjualan.objects.filter(Q(kobar__kode_grosir__icontains=query)).order_by('id')
    object_list = tm.ItemPesanan.objects.filter(
        Q(item_barang__status_data = '1') & (
        Q(item_barang__pembeli__nama_customer__icontains=query)
        )).order_by('tanggal')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'pusat/pesanan/menu_pemesanan_approve.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100] 
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'pusat/pesanan/data_pemesanan_approve.html',context)

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def daftarpemesanan_proses(request):
    user = request.user
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = tm.ItemPesanan.objects.filter(
        Q(item_barang__status_data = '2') & (
        Q(item_barang__pembeli__nama_customer__icontains=query) |
        Q(cu__profile__cabang=user.profile.cabang) |
        Q(tanggal=datetime.date.today())
        )).order_by('tanggal')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'pusat/pesanan/menu_pemesanan.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100] 
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'pusat/pesanan/data_pemesanan.html',context)


@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def export_pemesanan_excel(request):
    if request.method == 'POST':
        selected_ids = request.POST.getlist('selected_items')

        # Ambil data ItemPesanan berdasarkan ID pesanan yang dipilih
        item_pesanan_list = tm.ItemPesanan.objects.filter(item_barang_id__in=selected_ids)

        if not item_pesanan_list.exists():
            messages.error(request, "Tidak ada data yang dipilih untuk diekspor.")
            return HttpResponseRedirect(reverse('data_pesanan_pusat'))

        # Update status pesanan
        pesanan_ids = item_pesanan_list.values_list('item_barang_id', flat=True)
        tm.Pesanan.objects.filter(id__in=pesanan_ids).update(status_data='3')

        # Nama file
        today_date = datetime.datetime.now().strftime('%Y-%m-%d')
        filename = f"Daftar_Pemesanan_{today_date}.xlsx"

        # Buat file Excel di memory
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        worksheet = workbook.add_worksheet("Daftar Pemesanan")

        # Format header
        header_format = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': '#D3D3D3'})
        cell_format = workbook.add_format({'align': 'left'})
        currency_format = workbook.add_format({'num_format': '#,##0'})
        bold_format = workbook.add_format({'bold': True, 'align': 'right', 'bg_color': '#F2F2F2'})

        # Header
        headers = ["No", "Nama Customer", "Tanggal", "Nama Barang", "Kode Barang", "Jumlah Pesanan", "Harga Jual", "Total Harga"]
        for col_num, header in enumerate(headers):
            worksheet.write(0, col_num, header, header_format)

        # Data
        total_item, total_harga_jual, total_harga = 0, 0, 0
        for idx, item in enumerate(item_pesanan_list, start=1):
            worksheet.write(idx, 0, idx, cell_format)
            worksheet.write(idx, 1, item.item_barang.pembeli.nama_customer if item.item_barang.pembeli else "-", cell_format)  
            worksheet.write(idx, 2, item.item_barang.cdate.strftime('%Y-%m-%d'), cell_format)  
            worksheet.write(idx, 3, item.kobar.nama_barang if item.kobar else "-", cell_format)
            worksheet.write(idx, 4, item.kobar.kode_barang if item.kobar else "-", cell_format)
            worksheet.write_number(idx, 5, item.total_item or 0, cell_format)
            worksheet.write_number(idx, 6, item.harga_jual or 0, currency_format)
            worksheet.write_number(idx, 7, item.total_harga or 0, currency_format)

            # Akumulasi total
            total_item += item.total_item or 0
            total_harga_jual += item.harga_jual or 0
            total_harga += item.total_harga or 0

        # Summary
        summary_row = len(item_pesanan_list) + 1
        worksheet.write(summary_row, 4, "TOTAL:", bold_format)
        worksheet.write_number(summary_row, 5, total_item, bold_format)
        worksheet.write_number(summary_row, 6, total_harga_jual, currency_format)
        worksheet.write_number(summary_row, 7, total_harga, currency_format)

        # Simpan workbook ke memory
        workbook.close()
        output.seek(0)

        # Buat response untuk download langsung
        response = HttpResponse(output.read(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        response['Content-Disposition'] = f'attachment; filename="{slugify(filename)}"'

        return response  # Ini akan langsung memicu download di browser

    messages.error(request, "Invalid request.")
    return HttpResponseRedirect(reverse('data_pesanan_pusat'))


@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def daftarpemesanan_kirim(request):
    user = request.user
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = tm.ItemPesanan.objects.filter(
        Q(item_barang__status_data = '3') & (
        Q(item_barang__pembeli__nama_customer__icontains=query) |
        Q(cu__profile__cabang=user.profile.cabang) |
        Q(tanggal=datetime.date.today())
        )).order_by('tanggal')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'pusat/pesanan/menu_pemesanan_kirim.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100] 
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'pusat/pesanan/data_pemesanan_kirim.html',context)


@csrf_exempt
@login_required(login_url=settings.LOGIN_URL)
def update_jumlah_dikirim(request):
    if request.method == "POST":
        item_id = request.POST.get("item_id")
        jumlah_dikirim = int(request.POST.get("jumlah_dikirim", 0))

        try:
            item = tm.ItemPesanan.objects.get(id=item_id)
            item.jumlah_dikirim = jumlah_dikirim
            item.total_harga = jumlah_dikirim * (item.harga_jual or 0)
            item.save()

            # Perbarui total_pesan di Pesanan
            pesanan = item.item_barang
            pesanan.save()  # Memicu ulang perhitungan total_pesan

            return JsonResponse({"success": True, "total_pesan": pesanan.total_pesan()})
        except tm.ItemPesanan.DoesNotExist:
            return JsonResponse({"success": False, "error": "Item tidak ditemukan"})

    return JsonResponse({"success": False, "error": "Metode tidak diizinkan"})

@login_required(login_url=settings.LOGIN_URL)
def download_pdf_per_outlet(request, pesanan_id):
    pesanan = get_object_or_404(tm.Pesanan, id=pesanan_id)
    
    # Update status pesanan menjadi '4' (Selesai)
    pesanan.status_data = '4'
    pesanan.save()
    # Atur response untuk PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Pesanan_Outlet_{pesanan.id}.pdf"'

    # **Gunakan ukuran kertas struk (80mm x 297mm)**
    struk_width = 80 * mm
    struk_height = 297 * mm
    pdf = canvas.Canvas(response, pagesize=(struk_width, struk_height))
    
    # **Atur margin awal**
    y_position = struk_height - 10

    # **Nama Perusahaan (Tebal + Garis Bawah)**
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawCentredString(struk_width / 2, y_position, "Aling Hub Bandung")
    y_position -= 5
    pdf.line(10, y_position, struk_width - 10, y_position)  # Garis bawah
    y_position -= 15

    # **Header Struk**
    pdf.setFont("Helvetica-Bold", 10)
    pdf.drawString(10, y_position, f"Pesanan: {pesanan.pembeli.nama_customer}")
    y_position -= 12
    pdf.drawString(10, y_position, f"Outlet: {pesanan.cu.profile.cabang.nama_outlet}")
    y_position -= 12

    # **Menambahkan Tanggal Pesanan (cdate)**
    cdate_formatted = pesanan.cdate.strftime("%d-%m-%Y %H:%M:%S")
    pdf.setFont("Helvetica", 8)
    pdf.drawString(10, y_position, f"Tanggal Pesanan: {cdate_formatted}")
    y_position -= 20

    # **Daftar Item Pesanan**
    pdf.setFont("Helvetica", 8)
    for item in pesanan.item_pesanan.all():
        harga_formatted = "{:,.0f}".format(item.harga_jual).replace(",", ".")
        pdf.drawString(10, y_position, f"{item.kobar.nama_barang} x {item.jumlah_dikirim} @ {harga_formatted}")
        y_position -= 12  # Jarak antar item

    # **Total Harga dengan Titik Pemisah Ratusan**
    y_position -= 20
    pdf.setFont("Helvetica-Bold", 10)
    total_harga_formatted = "{:,.0f}".format(pesanan.total_harga()).replace(",", ".")
    pdf.drawString(10, y_position, f"Total: Rp {total_harga_formatted}")

    # **Simpan & kirim PDF**
    pdf.showPage()
    pdf.save()
    
    return response