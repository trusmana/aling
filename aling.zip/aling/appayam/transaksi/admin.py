from django.contrib import admin

from appayam.transaksi import models as mt

admin.site.register(mt.ItemPesanan)
admin.site.register(mt.Pesanan)
