from django.db import models

from apps.accounts import models as am
from apps.customer import models as cm
from appayam.barang import models as mb


STS_BAYAR = (('1',"Cash"),('2','Piutang'),('3','TF'),('4','Qris'))

STATUS_DATA = (('1','Proses'),('2','Terima'),('3','Kirim'), ('4','Outlet'),('5','Kirim-uang'),('6','Done'))

JENIS_PEMBELI = (('1','Perorangan'),('2','Mitra'),('3','Hub'),('4','Outlet'))

class Pesanan(models.Model):
    pembeli = models.ForeignKey(cm.Customer,related_name='p_customer', on_delete=models.CASCADE,null=True) 
    jenis_pembeli = models.CharField(choices= JENIS_PEMBELI, max_length=500,null=True, blank=True) 
    sts_bayar = models.CharField(choices= STS_BAYAR, max_length=500,null=True, blank=True)
    status_data  = models.CharField(choices= STATUS_DATA, max_length=500,null=True, blank=True ,default='1')
    cu = models.ForeignKey(am.AccountsUser, related_name='+', on_delete=models.CASCADE, editable=False, null=True, blank=True)
    cdate = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return f"Penjualan pada {self.cdate}"
    
    def total_harga(self):
        return sum([item.total_harga for item in self.item_pesanan.filter(total_harga__gt=0)])
    
    def total_pesan(self):
        return sum([item.total_item for item in self.item_pesanan.filter(total_item__gt=0)])
    
    def total_pesan_kirim(self):
        return sum([item.jumlah_dikirim for item in self.item_pesanan.filter(total_item__gt=0)])

    


class ItemPesanan(models.Model):
    item_barang = models.ForeignKey(Pesanan,related_name='item_pesanan', on_delete=models.CASCADE)    
    total_item = models.IntegerField(null=True)
    jumlah_dikirim = models.IntegerField(default=0)
    harga_jual = models.FloatField(null=True,blank=True)#####harga Pokok    
    total_harga = models.FloatField(null=True,blank=True) ### harga * barang    
    tanggal = models.DateField(null=True, blank=True)    
    kobar = models.ForeignKey(mb.Barang, on_delete=models.CASCADE, null=True, blank=True)
    keterangan = models.CharField(null=True,blank=True, max_length=50)
    
    cu = models.ForeignKey(am.AccountsUser, related_name='+', on_delete=models.CASCADE, null=True, blank=True)
    cdate = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Hitung total harga berdasarkan jumlah yang dikirim
        if self.item_barang.status_data == '4':
            self.total_harga = (self.total_item or 0) * (self.harga_jual or 0)
            super().save(*args, **kwargs)  

            # Perbarui total_pesan di model Pesanan
            if self.item_barang:
                self.item_barang.save() 

        else:
            self.total_harga = (self.jumlah_dikirim or 0) * (self.harga_jual or 0)
            super().save(*args, **kwargs)  

            # Perbarui total_pesan di model Pesanan
            if self.item_barang:
                self.item_barang.save() 
