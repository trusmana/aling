from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required,user_passes_test
from django.conf import settings
from django.http import Http404
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from django.core.paginator import Paginator
from django.forms import modelformset_factory,formset_factory
import json
import datetime
from datetime import date

from appayam.transaksi import models as tm
from apps.customer import models as cm
from appayam.barang import models as bm
from appayam.transaksi import forms as tf
from appayam.barang import forms as fbm
from apps.customer import forms as cf

@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def daftarpemesanan(request):
    user = request.user
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    # object_list = tm.ItemPenjualan.objects.filter(Q(kobar__kode_grosir__icontains=query)).order_by('id')
    object_list = tm.ItemPesanan.objects.filter(item_barang__status_data='1',cu__profile__cabang=user.profile.cabang).order_by('tanggal')
        # Q(item_barang__status_data = '1') & (
        # Q(item_barang__pembeli__nama_customer__icontains=query) |
        # Q(cu__profile__cabang=user.profile.cabang)
        # )).order_by('tanggal')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'pesanan/menu_pemesanan.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100] 
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'pesanan/data_pemesanan.html',context)



@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def addpesan(request):    
    user = request.user
    StokFormSet = formset_factory(tf.PesanForm, extra=1, can_delete=True)
    form_customer = tf.AddBeliForm()

    if request.method == 'POST':
        formset = StokFormSet(request.POST, prefix='items')
        form_customer = tf.AddBeliForm(request.POST)
        
        if formset.is_valid() and form_customer.is_valid():
            # Simpan data customer
            nama_customer = form_customer.cleaned_data['nama_customer']
            jenis_pembeli = form_customer.cleaned_data['jenis_pembeli']
            pesan = tm.Pesanan(pembeli=nama_customer, sts_bayar='2', cu=user, jenis_pembeli=jenis_pembeli)
            pesan.save()
            # Simpan setiap item pesanan dari formset
            for form in formset:
                if form.cleaned_data and not form.cleaned_data.get('DELETE'):  # Abaikan form yang dihapus
                    nama_barang = form.cleaned_data.get('nama_barang')
                    kode_produk = form.cleaned_data.get('kode_produk')
                    harga_jual = form.cleaned_data.get('harga_jual')  
                    jumlah_stok = form.cleaned_data.get('jumlah_stok', 0)
                    jumlah_pesanan = form.cleaned_data.get('jumlah_pesanan')
                    keterangan = form.cleaned_data.get('keterangan')
                    satuan = form.cleaned_data.get('satuan')
                    total = form.cleaned_data.get('total', 0)
                    br = bm.Barang.objects.get(kode_barang=kode_produk)
                    itempesanan = tm.ItemPesanan(
                        total_item=jumlah_pesanan, total_harga=total, kobar=br,
                        harga_jual=harga_jual, keterangan=keterangan, tanggal=datetime.date.today(), cu=user,
                        item_barang=pesan  # Hubungkan dengan pesan
                    )
                    itempesanan.save()

            messages.add_message(request, messages.INFO, 'Pesanan Barang telah tersimpan.')
            return redirect('data_pesanan')

    else:
        formset = StokFormSet(prefix='items')
    
    return render(request, 'pesanan/add_pesan.html', {
        'item_formset': formset,
        'form_customer': form_customer, 'customer_form': cf.CustomerForm(),
    })

@csrf_exempt
@login_required(login_url=settings.LOGIN_URL)
def add_customer_trans(request):
    if request.method == 'POST':
        customer_form = cf.CustomerForm(request.POST)
        print(customer_form)
        if customer_form.is_valid():
            pelanggan= customer_form.save(commit=False)
            pelanggan.cu = request.user
            pelanggan.save()
            return JsonResponse({
                'id': pelanggan.id,
                'nama': pelanggan.nama_customer,

            })
        else:
            return JsonResponse({'error': customer_form.errors}, status=400)

    return JsonResponse({'error': 'Invalid request ssssss'}, status=400)

@login_required(login_url=settings.LOGIN_URL)
def satuanbarang_modal_ajax(request):    
    products = bm.Stok.objects.filter(status__isnull = False)
    return render(request, 'pesanan/satuan_modal_ajax.html', {'products': products})

#############khusus Untuk datatable 
def item_datatable_satuan(request):
    products = bm.Stok.objects.filter(status__isnull=False)
    data = []
    for product in products:
        satuan = product.stok_barang.satuan_dasar.keterangan if product.stok_barang.satuan_dasar else "-"
        data.append({
            'kode': product.stok_barang.kode_barang,  
            'keterangan': product.stok_barang.nama_barang,  
            'harga': product.harga_jual, 
            'satuan': satuan,
            'aksi': f'<button class="btn btn-sm btn-primary btn-select-product"  data-satuan="{satuan}" data-kode="{product.stok_barang.kode_barang}"  data-name="{product.stok_barang.nama_barang}" data-harga="{product.harga_jual}" >Pilih</button>'
        })
    
    return JsonResponse({'data': data})


@csrf_exempt
@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser)
def change_status(request, pk):
    if request.method == "POST":
        obj = get_object_or_404(tm.Pesanan, pk=pk)
        obj.status_data = "2"  # Ubah status model
        obj.save()

        # Ambil data terbaru untuk tabel
        object_list = tm.Pesanan.objects.all()
        context = {"object_list": object_list}
        html_data_list = render_to_string("pesanan/menu_pemesanan.html", context, request=request)

        return JsonResponse({
            "message": "Status berhasil diubah",
            "html_data_list": html_data_list,
        })

    return JsonResponse({"error": "Invalid request"}, status=400)


@login_required(login_url=settings.LOGIN_URL)
@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def daftarpemesanan_kirim_pusat(request):
    user = request.user
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    # object_list = tm.ItemPenjualan.objects.filter(Q(kobar__kode_grosir__icontains=query)).order_by('id')
    object_list = tm.ItemPesanan.objects.filter(item_barang__status_data='4',cu__profile__cabang=user.profile.cabang).order_by('tanggal')
        # Q(item_barang__status_data = '1') & (
        # Q(item_barang__pembeli__nama_customer__icontains=query) |
        # Q(cu__profile__cabang=user.profile.cabang)
        # )).order_by('tanggal')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'pesanan/menu_pemesanan_kirim_pusat.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100] 
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'pesanan/data_pemesanan_kirim_pusat.html',context)