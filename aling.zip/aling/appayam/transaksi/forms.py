from django import forms

from apps.customer import models as cm
from appayam.transaksi import  models as tm



class AddBeliForm(forms.Form):
    nama_customer  = forms.ModelChoiceField(
        queryset=cm.Customer.objects.all(),
        widget=forms.Select(attrs={'class':'form-control select2'}),
    )
    jenis_pembeli = forms.ChoiceField(
    choices=[('', 'Pilih Jenis Pembeli'), ('1', 'Perorangan'), ('2', 'Mitra'),('3','Hub'),('4','Outlet')],
    required=False,
    widget=forms.Select(attrs={'class': 'form-control select2'}),
)
    
    
class PesanForm(forms.Form):
    nama_barang = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    kode_produk = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control kode_produk',
            'readonly': 'readonly',
        })
    )
    harga_jual = forms.IntegerField(widget=forms.TextInput(attrs={'size': 12,'class':'uang form-control harga_jual',
        'alt': 'integer','readonly':'True','name':'harga_jual',
    }))

    jumlah_stok = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control jumlah_stok',
            #'readonly': 'readonly',
        })
    )

    jumlah_pesanan = forms.IntegerField(
        widget=forms.TextInput(
            attrs={
                'class': 'uang form-control jumlah_pesanan',
                'alt': 'integer',
            }
        )
    )


    keterangan = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    satuan = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control satuan',
            'readonly': 'readonly',
        })
    )
    
    total = forms.IntegerField(widget=forms.TextInput(attrs={'size': 12,'class':'form-control total',
        'alt': 'integer','readonly':'True',
    }))


