from django.db import models

from apps.accounts import models as ma


class itemSatuanBarang(models.Model):
    kode = models.CharField(max_length=50)
    keterangan = models.CharField(max_length=50)
    status = models.BooleanField(default=True) 

    def __str__(self):
        return self.keterangan

class Barang(models.Model):
    kode_barang = models.CharField(max_length=500,blank=True,null=True)  # Kode unik barang
    nama_barang = models.CharField(max_length=200)
    satuan_dasar = models.ForeignKey(itemSatuanBarang, on_delete=models.CASCADE,null=True,blank=True)

    expired = models.DateField(blank=True, null=True)
    cu = models.ForeignKey(ma.AccountsUser, related_name='cu_barang', on_delete=models.CASCADE, editable=False, null=True, blank=True)
    mu = models.ForeignKey(ma.AccountsUser, related_name='mu_barang', on_delete=models.CASCADE, editable=False, null=True, blank=True)
    cdate = models.DateTimeField(auto_now_add=True)
    mdate = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.nama_barang


    def save(self, *args, **kwargs):
        if not self.kode_barang:
            satuan_id = self.satuan_dasar.id if self.satuan_dasar else 0
            counter = Barang.objects.count() + 1
            self.kode_barang = f"AL{satuan_id:01d}{counter:03d}"
        super(Barang, self).save(*args, **kwargs)

SATUAN_STOK = (('','-- CHOICES --'),('1','Kg'))

class Stok(models.Model):
    stok_barang = models.ForeignKey(Barang,related_name='Stok_Barang', on_delete=models.CASCADE,null=True,blank=True)

    satuan_stok = models.CharField(choices= SATUAN_STOK, max_length=50,null=True,default='1')
    jumlah_stok = models.DecimalField(null=True, max_digits=5, decimal_places=2)
    harga_jual = models.DecimalField(max_digits=10, decimal_places=2,null=True,default=0)
    status = models.BooleanField(default=True,null=True)
    
    cu = models.ForeignKey(ma.AccountsUser, related_name='cu_stok', on_delete=models.CASCADE, editable=False, null=True, blank=True)
    mu = models.ForeignKey(ma.AccountsUser, related_name='mu_stok', on_delete=models.CASCADE, editable=False, null=True, blank=True)
    cdate = models.DateTimeField(auto_now_add=True)
    mdate = models.DateField(null=True,blank=True)####Tanggal ke tika ReStok


    def __str__(self):
        return self.stok_barang.nama_barang
    

STATUS_HISTORY = (('1','New'),('2','ReStok'))

class HargaJualHistory(models.Model):
    stok_barang = models.ForeignKey(Stok, on_delete=models.CASCADE)  # Barang terkait
    harga_jual = models.FloatField()
    stok_history= models.IntegerField(null=True)  # Jumlah isi per satuan (misal 1 pcs, 10 pcs dalam box)
    satuan_stok = models.CharField(choices= SATUAN_STOK, max_length=50,null=True,default='1')
    tanggal_efektif = models.DateField(auto_now_add=True)  # Tanggal perubahan harga jual
    created_at = models.DateTimeField(auto_now_add=True)
    status_trans = models.CharField(choices= STATUS_HISTORY, max_length=50,null=True,default='1')