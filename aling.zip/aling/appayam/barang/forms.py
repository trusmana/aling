from django import forms
from django.forms import inlineformset_factory
from appayam.barang import models as mb

class BarangForm(forms.ModelForm):
    class Meta:
        model = mb.Barang
        fields = [
            'nama_barang', 'satuan_dasar','expired'
        ]
        widgets = {
            'nama_barang': forms.TextInput(attrs={'class': 'form-control'}),
            'satuan_dasar': forms.Select(attrs={'class': 'form-control select2 form-satuan'}), 
            'expired': forms.DateInput(attrs={'class': 'form-control'}),
        }

class StokForm(forms.ModelForm):
    harga_jual = forms.IntegerField(widget=forms.TextInput(attrs={'class':'uang form-control harga_jual',
        }))
    class Meta:
        model = mb.Stok
        fields = ['stok_barang', 'jumlah_stok', 'harga_jual','satuan_stok']
        widgets = {
            'satuan_stok': forms.Select(attrs={'class': 'form-control select2'}),
            'jumlah_stok':forms.NumberInput(attrs={'class': 'form-control uang jumlah_stok'}),
            'jenis_satuan': forms.Select(attrs={'class': 'form-control'}),
        }


HargaJualFormSet = inlineformset_factory(
    mb.Barang, mb.Stok, form=StokForm,
    extra=1,  
    can_delete=True
)
