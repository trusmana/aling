from django.urls import path

from appayam.barang import views as jba

urlpatterns = [
    path('jenis-barang/', jba.Baranglist, name='barang_list'),
    path('barang-grosir/create/', jba.create_barang, name='create_barang'),

    ###size
    path('size/create/', jba.add_size, name='add_size'),
]
