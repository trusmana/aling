from django.contrib import admin

from appayam.barang import models as bm

admin.site.register(bm.Barang)
admin.site.register(bm.Stok)
admin.site.register(bm.itemSatuanBarang)
admin.site.register(bm.HargaJualHistory)