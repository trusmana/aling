from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required,user_passes_test
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.core.paginator import Paginator
from django.db.models import Q
from decimal import Decimal
from django.http import JsonResponse
from django.contrib import messages
from django.forms import modelformset_factory

from appayam.barang import models as bm
from appayam.barang import forms as fbm
 

@login_required(login_url=settings.LOGIN_URL)
#@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def Baranglist(request):
    query = request.GET.get('search')
    entries = int(request.GET.get('entries', 20))
    if query == None:
        query = ''
    object_list = bm.Stok.objects.filter(Q(stok_barang__nama_barang__icontains=query)).order_by('id')
    paginator = Paginator(object_list, entries)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    
    is_ajax_request = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    if is_ajax_request:
        return render(request, 'barang/menu_barang.html', {'datas': page_obj})
    entries_options = [5, 10, 20, 50, 100]  # Daftar opsi entri yang tersedia
    context = {'datas': page_obj,'entries_options': entries_options,'selected_entries': entries,}
    return render(request,'barang/barang_list.html',context)


@login_required(login_url=settings.LOGIN_URL)
#@user_passes_test(lambda u: u.is_superuser or u.groups.filter(name='Admin').exists())
def create_barang(request):    
    user = request.user
    stok_form = fbm.StokForm(request.POST)  
    if request.method == 'POST':
        form = fbm.BarangForm(request.POST)              
        if form.is_valid() and stok_form.is_valid():
            harga_jual= stok_form.cleaned_data['harga_jual']
            jumlah_stok= stok_form.cleaned_data['jumlah_stok']
            satuan_stok= stok_form.cleaned_data['satuan_stok']
            barang= form.save(commit=False)
            barang.save()
            stok_masuk =bm.Stok(stok_barang = barang, harga_jual=harga_jual,jumlah_stok=jumlah_stok,satuan_stok=satuan_stok)
            stok_masuk.save()
            history =bm.HargaJualHistory(
                stok_barang=stok_masuk,
                harga_jual=harga_jual,
                stok_history=jumlah_stok,
                satuan_stok = satuan_stok,
                status_trans='1'  # Status New
            )
            history.save()
            messages.add_message(request, messages.INFO, 'Barang Telah tersimpan')
            return redirect('barang_list')
    else:
        form = fbm.BarangForm()
    
    return render(request, 'barang/create_barang.html', {
        'form': form,
        'item_formset': stok_form
    })


@csrf_exempt
@login_required(login_url=settings.LOGIN_URL)
def add_size(request):
    if request.method == 'POST':
        size_form = fbm.SizeForm(request.POST)
        if size_form.is_valid():
            size = size_form.save()
            # Kembalikan data customer yang baru disimpan sebagai response JSON
            return JsonResponse({
                'id': size.id,
                'nama_ukuran': size.nama_ukuran,
                # 'status':True
            })
        else:
            return JsonResponse({'error': size_form.errors}, status=400)

    return JsonResponse({'error': 'Invalid request'}, status=400)